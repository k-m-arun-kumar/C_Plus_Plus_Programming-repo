/* ********************************************************************
FILE                   : time.cpp

PROGRAM DESCRIPTION    :  input time, if time = 12 then hour = 12, min = 0 and sec =0 in 24 hour format, if time = 12:01 then hour = 12, min = 01 and sec = 00 in 24 hour format if input time = 9:01 pm, then hour = 21, min = 01 and sec =0 in 24 hour format 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <iostream>
#include <string>
#include <regex>
#define DEBUG 00

#define INVALID_DATA     00
#define HOUR_DATA        01
#define MINUTE_DATA      02
#define SECONDS_DATA     03
#define MERIDIAN_DATA    04

#define SEPERATOR_COLON  01
#define VALID_DATA       02
#define SEPERATOR_SPACE  03


#define SUCCESS               0
#define ERROR_NO_TRAIL_DATA   -1
#define ERROR_NO_LEAD_DATA    -2
#define ERROR_NO_LEAD_COLON    -3
#define ERROR_LEAD_COLON        -4
#define ERROR_SEPERATOR        -5
#define ERROR_NULL_DATA        -6
#define LAST_DATA              -7
#define ERROR_LEAD_SPACE       -8
#define ERROR_BLANK_DATA       -9
#define ERROR_TOO_MANY_PARAMETER -10
/* HOUR_24 = 00 if time format in am or pm eg 12:45:23 am.
   For  HOUR_24 = 01 if time is in railway format eg 23:45:23 */
using namespace std;
struct Time
{
	int hour, min,sec; 
	bool hour_24;
	bool is_pm;
};

Time time_format;
Time& sec_time(const long& );
long int calc_timestamp(const Time );
int input_time_format(string&, Time& );
void disp_seperator( int = 50, char ='=');
int validate_time(const string& str_time, Time& input_time);
int abstract_data(const string& input_string, string& data_str, string& next_datas_str,const int& data_seperator = VALID_DATA );
int white_space_remove(const string& input_string, string& data_str);
void disp_error(const int& error_code);
int data_count = INVALID_DATA;
int main()
{
    long seconds_time, disp_timestamp;
    Time time_stamp, input_time;
    string to_iterate, str_input_time;
    do
    {
    	if(!input_time_format( str_input_time, input_time))
    	{
	    	 disp_timestamp = calc_timestamp(input_time );
	    	 cout<<"\n ANS[01]: For time "<<str_input_time<<" , time stamp : "<<disp_timestamp<<" seconds";
    	}
        disp_seperator();
    	cout<<"\n Enter time stamp in seconds: ";
    	cin>>seconds_time;

        time_stamp = sec_time(seconds_time);
        cout<<"\n ANS[02]: For time stamp - "<<seconds_time<<" in seconds , hour = "<<time_format.hour<<" : min = "<<time_format.min<<" : sec = "<<time_format.sec;
        disp_seperator();
        cout<<"\n Do you want to continue(y/n): Enter - ";
        cin>>to_iterate;
    } while (to_iterate.length() == 1 &&(to_iterate.at(0) =='y' || to_iterate.at(0) =='Y'));
	return 0;
}
int input_time_format( string& get_time, Time& input_time)
{
	string to_iterate = "n";

	do
    {
       cout<<"\n Enter time format in hh[:min:sec (am/pm)] = "; 
	      
	   cin.sync(); 
       getline(cin,get_time);
         if(!validate_time(get_time, input_time ))
        {
	         return 0;
        }
       
        cout<<"\n Do you want to continue(y/n): Enter - ";
        cin>>to_iterate;
    } while (to_iterate.length() == 1 && (to_iterate.at(0) =='y' || to_iterate.at(0) =='Y'));
    return 1;
}

 /* remove leading and trailng whitespace from input_string and store trunicated string in nospace_data_str
   eg if input_string = "  24   ", then nospace_data_str = "24" */
int white_space_remove(const string& input_string, string& nospace_data_str)
{
	size_t nonspace_lead , non_space_trail ;
	string whitespaces (" \t\f\v\n\r"), temp_str;	 
 	/* detect pos of char at leading white spaces*/  
	nonspace_lead = input_string.find_first_not_of(whitespaces);
	if(nonspace_lead == string::npos)
    {
	     if(DEBUG)
	        cout<<"\n ERROR[40]: ERROR_NO_LEAD_DATA, input_string = "<<input_string<<", data_count = "<<data_count;
		  return ERROR_NO_LEAD_DATA;
	}

	/* detect pos of char at trailing white spaces*/
	non_space_trail = input_string.find_last_not_of(whitespaces);
    if (non_space_trail == string::npos)
    {
    	 if(DEBUG)
	        cout<<"\n ERROR[41]: ERROR_NO_TRAIL_DATA, input_string = "<<input_string<<", data_count = "<<data_count;
	   return ERROR_NO_TRAIL_DATA; 
    }
  /* remove leading and trailng whitespace from input_string and store trunicated string in nospace_data_str */
	nospace_data_str = input_string.substr(nonspace_lead,non_space_trail -nonspace_lead + 1 );
	if(DEBUG)
	{
		cout<<"\n INFO[32]: extract data_string = "<<input_string<<", from "<<nonspace_lead<<" to "<<non_space_trail<<" , nospace_data_str = "<<nospace_data_str<<".";
	}
	    
	return non_space_trail;
}
/* from input_string, extract parameter data without leading and trailing white space and store it in data_string, store
  next parameter string without leading white space in next_datas_str 
  eg. input_string = "12  : 34  am" , data_string = "12", next_datas_str = "34  am", if seperator =  SEPERATOR_COLON,
   if input_string = "34    am" , data_string = "34", next_datas_str = "am", if seperator =  SEPERATOR_SPACE,
   if input_string = "  12  : 01   am   " , data_string = "12  : 01   am", if seperator =  VALID_DATA */
int abstract_data(const string& input_string, string& data_string, string& next_datas_str, const int& seperator)
{
	 size_t found_col = 0, found_space = 0 ;
	 string sub_str, lead_space_next_datas_str;
	 string whitespaces (" \t\f\v\n\r");
	 int ret_val;
	 size_t data_end, non_space_trail, next_datas_start ;
	 
	 if(input_string.length() ==0)
	 {
	    if(DEBUG)
	        cout<<"\n ERROR[42]: ERROR_NULL_DATA of input_string, data_count = "<<data_count;
		return ERROR_NULL_DATA;   
     }
	switch(seperator)
	{
		case SEPERATOR_COLON:
		    found_col  = input_string.find_first_of(":");
		    if(found_col ==string::npos)		      
			{
			   if(DEBUG)
	               cout<<"\n ERROR[43]: ERROR_NO_LEAD_COLON, input_string = "<<input_string<<", data_count = "<<data_count;
			   return ERROR_NO_LEAD_COLON;
			} 
			/* sub_str =  parameter with seperator as first ':' char, eg if input_string = "12   :  23   am", sub_str="12   " and data_str = "12"  */
		    sub_str = input_string.substr(0,found_col); 
			if(sub_str.find_first_not_of(whitespaces) == string::npos)
			{
			  if(DEBUG)
	               cout<<"\n ERROR[45]: ERROR_BLANK_DATA, input_string = "<<input_string<<", sub_str = "<<sub_str<<", data_count = "<<data_count;
			 	return ERROR_BLANK_DATA;
			}
		    /* remove lead and trail whitespace from parameter */
		    if((non_space_trail =white_space_remove(sub_str, data_string)) <SUCCESS)
		    {
			  if(DEBUG)
	               cout<<"\n ERROR[46]: white space trail error, input_string = "<<input_string<<", sub_str = "<<sub_str<<", data_count = "<<data_count;
			    return non_space_trail;
		    }
		    if(DEBUG)
	        {
	         	cout<<"\n INFO[29]: input_string = "<<input_string<<", ':' sep pos found = "<<found_col;
         	} 
           
         	lead_space_next_datas_str = input_string.substr(found_col+1);
         	next_datas_start =lead_space_next_datas_str.find_first_not_of(whitespaces);
         	if( next_datas_start==string::npos)		      
			{
				if(DEBUG)
	               cout<<"\n ERROR[47]: ERROR_BLANK_DATA , input_string = "<<input_string<<",lead_space_next_datas_str = "<<lead_space_next_datas_str<<", data_count = "<<data_count;
				return ERROR_BLANK_DATA;
			} 
			if(lead_space_next_datas_str.length() < next_datas_start)
			{
			   if(DEBUG)
			     cout<<"\n ERROR[50]: ERROR_NULL_DATA, lead_space_next_datas_str = "<<lead_space_next_datas_str<<", data_count = "<<data_count;  
               return ERROR_NULL_DATA; 
            }
            /* sub_str =  parameter with seperator as first ':' char, eg if input_string = "12   :  23   am", sub_str="12   ", data_str = "12", lead_space_next_datas_str = "  23   am"
			and  next_datas_str = "23   am" */
	        next_datas_str = lead_space_next_datas_str.substr(next_datas_start); 
	        ret_val = ERROR_LEAD_COLON;
		    break;
		case VALID_DATA:
		  	
	        if(( non_space_trail=white_space_remove(input_string, data_string)) <SUCCESS)
		    {
			   if(DEBUG)
	               cout<<"\n ERROR[48]: white space trail error, input_string = "<<input_string<<", data_count = "<<data_count; 
				return non_space_trail;
		    }
		    if(DEBUG)
	        {
	         	cout<<"\n INFO[30]: input_string = "<<input_string<<", last data's non space char pos found = "<<non_space_trail;
         	} 
             ret_val = SUCCESS;    	  
		   break;
		case SEPERATOR_SPACE:  
		   found_space  = input_string.find_first_of(whitespaces);
		    if( found_space==string::npos)		      
			{
				data_string = input_string;
				return LAST_DATA;
			} 
		
		    sub_str = input_string.substr(0,found_space);   
		    if((non_space_trail =white_space_remove(sub_str, data_string)) <SUCCESS)
		    {
		    	if(DEBUG)
	               cout<<"\n ERROR[49]: white space trail error, input_string = "<<input_string<<", sub_str = "<<sub_str<<", data_count = "<<data_count; 
			    return non_space_trail;
		    }
		    if(DEBUG)
	        {
	         	cout<<"\n INFO[38]: input_string = "<<input_string<<", first space pos found = "<<found_space;
         	} 
            lead_space_next_datas_str = input_string.substr(found_space+1);
         	next_datas_start =lead_space_next_datas_str.find_first_not_of(whitespaces);
         	if( next_datas_start==string::npos)		      
			{
				return LAST_DATA;
			} 
			if(lead_space_next_datas_str.length() < next_datas_start) 
			{
			   if(DEBUG)
			     cout<<"\n ERROR[51]: ERROR_NULL_DATA, lead_space_next_datas_str = "<<lead_space_next_datas_str<<", data_count = "<<data_count;  	
			  
               return ERROR_NULL_DATA; 
            }
             /* sub_str =  parameter with seperator as first 'whitespace' char, eg if input_string = "23  am", sub_str="  am", data_str = "23", lead_space_next_datas_str = " am"
			and  next_datas_str = "am" */
	        next_datas_str = lead_space_next_datas_str.substr(next_datas_start); 
	        ret_val = SUCCESS;
		   break;		   
		default:
		   disp_error(ERROR_SEPERATOR);
		   cout<<" = "<<seperator;
		  return ERROR_SEPERATOR; 
	}  
	if(DEBUG)
	{
	   	cout<<"\n INFO[31]: data_string = "<<data_string<<", next_datas_str = "<<next_datas_str<<", seperator = "<<seperator<<", data_count = "<<data_count;
    }  		 	
    return ret_val;	
}
int validate_time(const string& str_time, Time& input_time)
{
	 string next_datas_str,  compare_str, data_str, cur_time_str;
	 int  error_code, error_code_space, num_col =0, next_data = HOUR_DATA ;
	 bool to_continue = true, result = false;
	 Time temp_time = {0,0,0,true,false};
	 size_t sz;
      long int valid_data;
    temp_time.hour_24 = true;
    
    if(DEBUG)
	    cout<<"\n INFO[16]: Given time string = "<<str_time<< " of len = "<<str_time.length();
	if((error_code = abstract_data(str_time, data_str, next_datas_str)) != SUCCESS)
	{
		disp_error(error_code);
		cout<<", str_time = "<<str_time;
		return 1;
	} 
         
	if(DEBUG)
	  cout<<"\n INFO[25]: valid time string = "<<data_str<< " of len = "<<data_str.length() ;
	  cur_time_str = data_str;
	  
	  data_count = HOUR_DATA;	
	  do
	  {
	  
	  	/* next_datas_str = time to process at and after time format, eg if "12: 45:  23", then for hour, next_datas_str = 12:45:23 .
		  For minute, next_datas_str = "45:  23", for seconds, next_datas_str = "23" */		     
			
		/* for hour and minute get data present between ':' character, eg 12:45:23, data_str = "12" for hour,
		      data_str = "45" for minute, data_str = "23" for seconds 	*/ 		    
	   	
	     /* if hour, minute or seconds begins with non integer */
	   error_code = abstract_data(cur_time_str, data_str, next_datas_str,SEPERATOR_COLON );
	   switch(error_code)
	   {
	   	   case ERROR_NO_LEAD_COLON:
	   	   	  error_code_space = abstract_data(cur_time_str, data_str, next_datas_str,SEPERATOR_SPACE );
	   	   	  switch(error_code_space)
	   	   	  {
	   	   	    	 case LAST_DATA:
	   	   	  	       to_continue = false;
	   	   	  	       result = true;
	   	   	  	       next_data = INVALID_DATA;
	   	   	  	 	   break; 	 	 
					  case SUCCESS:
					  ;	
					  break;	    
	   	   	  	     default:
				       disp_error(error_code_space);
		               return 1; 	 	  
			      
		      }
	   	   	  break;
	   	   case ERROR_LEAD_COLON:
	   	   case SUCCESS:
			   ;	
			break;			  
	   	   default:
			  disp_error(error_code);
		      return 1; 	  
	   }
	   if(DEBUG)
		    cout<<"\n INFO[36]: data_count = "<<data_count<<" , data_str = "<<data_str<<", cur_time_str = "<<cur_time_str<<", next_datas_str = "<<next_datas_str<<".";   
	   if( (data_count>= HOUR_DATA && data_count<= SECONDS_DATA) ) 
        {
        	if( data_str.length() == 0 || !(data_str.at(0) >= '0' && data_str.at(0) <= '9' ) )
        	{
			  	cout<<"\n ERROR[02]: begins with non integer : data_str = "<<data_str<<", next_datas_str = "<<next_datas_str<<".";
            	return 1;
            }
            /* if data_str = "02", , valid_data =2 not as 02, so
			convert from valid_data to string =2 not as 02, so does not match with data_str = 02 and compare_str = 2 */
            while(data_str.at(0) =='0'&& data_str.length() != 1 )
            {
               data_str = data_str.substr(1);	
			}
			/* if data_str was "0002", then data_str = "2" */
        	valid_data = stol(data_str, &sz, 10);
            
    	    compare_str = to_string(valid_data);
    	    /* abstract data is integer ie if 12e:45:23, then data_str = 12e for hour, which is not a integer*/
    	    if(compare_str.compare(data_str) != 0)
    	    {
    	    	cout<<"\n ERROR[03]: begins with numeric but has non integer before ':' character. data_str = "<<data_str<<", compare_str = "<<compare_str<<".";
    	    	return 1;
	    	}
		}  
	    switch(data_count)
		{
		    case HOUR_DATA:
		       /* hour data - valid range */
			   	if( (valid_data < 0 || valid_data > 23 ))
    	        {
    		        cout<<"\n ERROR[04]: invalid integer hour = "<<valid_data;
    		        return 1;
		        }
		        temp_time.hour_24 = true; 
				temp_time.hour = valid_data; 
		        switch(error_code)
	            {		
	                case SUCCESS:
	                case ERROR_LEAD_COLON:
	                   next_data = MINUTE_DATA;
	                  ++num_col;
	                  break;
	                case ERROR_NO_LEAD_COLON:
	                   error_code_space = abstract_data(cur_time_str, data_str, next_datas_str,SEPERATOR_SPACE  );
					  					
	   	   	             switch(error_code_space)
	   	   	             {
	   	   	            	 case LAST_DATA:
	   	   	  	               to_continue = false;
	   	   	  	               result = true;
	   	   	  	               next_data = INVALID_DATA;
	   	   	  	 	           break;
	   	   	  	 	      	case SUCCESS:
					         	;	
		                      break;   
	   	   	  	            default:
				              disp_error(error_code_space);
		                       return 1; 	 	  
			             }
		               
	                  next_data = MERIDIAN_DATA;
	                  break;
	                case ERROR_NULL_DATA:
	                case ERROR_NO_LEAD_DATA:
		            case ERROR_NO_TRAIL_DATA:  
		              to_continue = false;
		              next_data = INVALID_DATA;
    	              result = true;
			          if(DEBUG)
    	                 cout<<"\n INFO[37]: Correct 24 hour format: Hour = "<<input_time.hour<<", Min = "<<input_time.min<<" & Secs = "<< input_time.sec;	
					  break;	      
		            default:
		               disp_error(error_code);
		               return 1;  
                 }
				 
				if(DEBUG)
    	           cout<<"\n INFO[03]: Hour = "<<temp_time.hour<<" & next data = "<<next_data<<", data_str = "<<data_str<<", next_datas_str = "<<next_datas_str<<".";  
    	        break;
    	    case MINUTE_DATA:
    	    	/* minute data - valid range */
			  if(!(valid_data >=0 && valid_data<=59 ))
    	        {
    		        cout<<"\n ERROR[05]: invalid integer minute = "<<valid_data;
    		        return 1;
		        }
		        temp_time.min = valid_data;
				 temp_time.hour_24 = true;  
    	      
    	       switch(error_code)
	           {		
	               case SUCCESS:
	               case ERROR_LEAD_COLON:
		              next_data = SECONDS_DATA;
		             ++num_col;
		              break;
		           case ERROR_NO_LEAD_COLON:
		           	error_code_space = abstract_data(cur_time_str, data_str, next_datas_str, SEPERATOR_SPACE );
		           	switch(error_code_space)
		           	{					  
	   	   	        	 case LAST_DATA:
	   	   	  	            to_continue = false;
	   	   	  	            result = true;
	   	   	  	            next_data = INVALID_DATA;
	   	   	  	 	        break;
	   	   	  	 	      case SUCCESS:
	   	   	  	 	      	;
							break;		   								         
	   	   	  	         default:
				            disp_error(error_code_space);
		                    return 1;   
			           
		              } 
		              next_data = MERIDIAN_DATA;
		              break;
		           case ERROR_NULL_DATA:
				   case ERROR_NO_LEAD_DATA:
				   case ERROR_NO_TRAIL_DATA:  
				       to_continue = false;
				       next_data = INVALID_DATA;   
					  result  = true;     
					if(DEBUG)
    	               cout<<"\n INFO[36]: Correct 24 hour format: Hour = "<<input_time.hour<<", Min = "<<input_time.min<<" & Secs = "<< input_time.sec;	    
		           default:
		             disp_error(error_code);
		             return 1;  
                }  
                  
    	        if(DEBUG)
    	           cout<<"\n INFO[03]: Minute = "<<temp_time.min<<", next data = "<<next_data<<", data_str = "<<data_str<<", next_datas_str = "<<next_datas_str<<".";
    	        break;    	    	     	
    	    case SECONDS_DATA:
    	        /* seconds data - valid range */
    	     	if(!(valid_data >=0 && valid_data<=59 ))
    	        {
    		        cout<<"\n ERROR[06]: invalid integer second = "<<valid_data;
    		        return 1;
		        }
		       
		       temp_time.sec = valid_data;
		       temp_time.hour_24 = true; 
    	       switch(error_code)
	           {		
	               case ERROR_LEAD_COLON:
	               	++num_col;
	                 cout<<"\n ERROR[33]: invalid nos of ':' char = "<<num_col<<", data_str = "<<data_str<<", cur_time_str = "<<cur_time_str<<", next_datas_str = "<<next_datas_str<<".";
		             return 1;		            
		           case ERROR_NO_LEAD_COLON:
		              error_code_space = abstract_data(cur_time_str, data_str, next_datas_str, SEPERATOR_SPACE );
		              switch(error_code_space)
	   	   	          {
	   	   	            	 case LAST_DATA:
	   	   	  	               to_continue = false;
	   	   	  	               next_data = INVALID_DATA;
	   	   	  	               result = true;
	   	   	  	 	           break;
	   	   	  	 	         case SUCCESS:
								 ;  
							  break;	 
	   	   	  	            default:
				              disp_error(error_code_space);
		                       return 1; 	 	  
			          }		             
					  next_data = MERIDIAN_DATA;
		              break;
		           case ERROR_NULL_DATA:
				   case ERROR_NO_LEAD_DATA:    
		           case ERROR_NO_TRAIL_DATA:  
				       to_continue = false;
				       
    	              next_data = INVALID_DATA;
    	              result = true;
			       
		           default:
		             disp_error(error_code);
		             return 1;  
                }  
                if(DEBUG)
    	           cout<<"\n INFO[21]: Seconds = "<< temp_time.sec<<" & next data = "<<next_data<<", data_str = "<<data_str<<", next_datas_str = "<<next_datas_str<<"." ; 
		        break;	
			case MERIDIAN_DATA: 
    	          /* for meridian data, only for 12 hour time format */
    	           error_code = abstract_data(cur_time_str, data_str, next_datas_str,SEPERATOR_SPACE );
	               switch(error_code)
	                {		
	                    case ERROR_NULL_DATA:
	                    case LAST_DATA:	
	                      to_continue = false;
	                      next_data = INVALID_DATA;
	                      result = true;
		                 break;
		               default:
		                 disp_error(ERROR_TOO_MANY_PARAMETER);
		                 cout<<", next_datas_str = "<<next_datas_str;
		                 return 1;  
                    }     
    	         
			        if(data_str.length()!=0 && (data_str.compare("am") ==0 ||data_str.compare("AM") ==0 || data_str.compare("Am") ==0 || data_str.compare("aM") ==0)	)
		         	{
		         	    temp_time.is_pm = false;
		         	    temp_time.hour_24 = false;
		         	    if(DEBUG)
			            	cout<<"\n INFO[14]: 12 hour AM meridian ";	
		            }
		            else if(data_str.length()!=0 && (data_str.compare("pm") ==0 ||data_str.compare("PM") ==0 || data_str.compare("Pm") ==0 || data_str.compare("pM") ==0))
		            {
		            	 temp_time.is_pm = true;
		            	 temp_time.hour_24 = false;
		            	 if(DEBUG)
		                	 cout<<"\n INFO[15]: 12 hour PM meridian ";
		         	}
					 else
					 {
					 	cout<<"\n ERROR[19]: Invalid meridian = "<<data_str<<".";
					 	return 1;
					 }
					if( !temp_time.hour_24 &&  temp_time.hour>12)
					{
						 cout<<"\n ERROR[34]: invalid integer hour = "<< temp_time.hour;
    		               return 1;               
		     		}
				   
				   /*so, if the meridian is present and it's "AM", then convert 12:00 AM to 24 hour time = 0:00. 
				If the meridian is present and it's "PM", then convert everything starting with 1:00 PM to its corresponding 24 hour time.
				 Everything "AM" except 12:00 AM is left alone, and everything "PM" except 12:00 PM is adjusted. 
				 for 12:00 PM, corresponding 24 hour time = 12.00 */ 	 
				  if ( (!temp_time.is_pm) && ( temp_time.hour == 12) ) 
				   {  
				        temp_time.hour = 0;
				   } 
                   if ( (temp_time.is_pm) && (  temp_time.hour < 12) ) 
				   {  
				      temp_time.hour += 12;
				   } 	
                                       
                break;             
			    
    	     default:
			    cout<<"\n ERROR[07]: Invalid data_count = "<<data_count;
				return 1;
	    }
	     data_count = next_data;
         cur_time_str = next_datas_str; 
		 
      } while(to_continue == true );
     if(result) 
     {
     	input_time.hour = temp_time.hour;
		input_time.min = temp_time.min;
    	input_time.sec = temp_time.sec;
    	input_time.hour_24 = temp_time.hour_24; 
    	input_time.is_pm = temp_time.is_pm;
	    cout<<"\n INFO[20]: Correct 24 hour format: Hour = "<<input_time.hour<<" , Min = "<<input_time.min<<" & Secs = "<< input_time.sec;	  
     }
     return 0;
    
}

Time& sec_time(const long& sec )
{
	long temp, temp2 ;
	time_format.sec  = static_cast<int> (sec % 60);
	temp = sec - time_format.sec ;
	temp2 = (temp % 3600);
	time_format.min = temp2 /60;
	time_format.hour =  (temp - temp2)/3600;
	return time_format;
}
long int calc_timestamp(const Time time )
{
	return	time.sec + time.min * 60 + time.hour * 3600;
}

void disp_error(const int& error_code)
{
	switch(error_code)
	{
		case ERROR_NO_TRAIL_DATA:
			cout<<"\n ERROR[28]: No Trail non space character";
			break;
		case ERROR_NO_LEAD_DATA:
		    cout<<"\n ERROR[29]: No Lead non space character ";
		    break;
		case  ERROR_LEAD_COLON:
		    cout<<"\n ERROR[30]: presence of lead ':' character ";
		    break;
		 case  ERROR_NO_LEAD_COLON:
		    cout<<"\n ERROR[31]: No Lead ':' character ";
		    break; 
		case ERROR_SEPERATOR:
		    cout<<"\n ERROR[32]: Invalid seperator opererator key ";
		    break;
		case ERROR_NULL_DATA:
		    cout<<"\n ERROR[33]: Null data ";
		    break;	
		case ERROR_BLANK_DATA:
		    cout<<"\n ERROR[35]: Missing parameter ";
		    break;	
    	case ERROR_TOO_MANY_PARAMETER:
    		cout<<"\n ERROR[36]: Too many parameters ";
		    break;		  
	    default:
	    	cout<<"\n ERROR[34]: Invalid error code = "<<error_code;		 
	}
	return ;
}
void disp_seperator( int num_disp,char ch )
{
	cout<<endl;
	for(int i = 0; i< num_disp; ++i)
	  cout<<ch;
	return;
}
