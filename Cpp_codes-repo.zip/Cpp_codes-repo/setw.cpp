/* ********************************************************************
FILE                   : setw.cpp

PROGRAM DESCRIPTION    : practise setw function

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
long int pop1=2425785L, pop2=47, pop3=9761;
cout /*<< setw(8) <<*/ LOCATION << POPULATION << endl                                     \
<<  Portcity << pop1 << endl        \
<<Hightown << pop2 << endl        \
<< Lowville << pop3 << endl;
return 0;
}
