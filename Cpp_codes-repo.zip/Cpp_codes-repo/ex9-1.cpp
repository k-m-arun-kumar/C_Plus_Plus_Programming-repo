/* ********************************************************************
FILE                   : ex9-1.cpp

PROGRAM DESCRIPTION    : 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <iostream>
#include <string>
using namespace std;
class publication
{
	private:
    	string title;
	    float price;
	
	public: 
	   void getdata()
	   {
	   	 cin.sync();
	   	 cout<<"\n Enter title : ";
	   	 getline(cin, title,'\n');
	   	 cout<<"\n Enter price : ";
	   	 cin>>price;
	   	 return;
	   }
	   void putdata()
	   {
	   	  cout<<"\n Title : "<<title;
	   	  cout<<"\n Price : "<<price;
	   	  return;
	   }
};

class book: public publication
{
	int pagecount;
	
	
	public: 
	   void getdata()
	   {
	   	 cout<<"\n Enter page count : ";
	     cin>>pagecount;
	   	
	   	 return;
	   }
	   void putdata()
	   {
	   	  cout<<"\n Page count : "<<pagecount;
	   	  return;
	   }
};
class tape :  public publication
{
	float playtime;
	
	public: 
	   void getdata()
	   {
	   	 cout<<"\n Enter play time  : ";
	   	 cin>>playtime;
	   	 return;
	   }
	   void putdata()
	   {
	   	  cout<<"\n Play Time  : "<<playtime;
	   	  return;
	   }
};

int main()
{
	book book_obj;
	tape tape_obj;
	
	book_obj.publication::getdata();
	book_obj.getdata();
	
	tape_obj.publication::getdata();
	tape_obj.getdata();
	
	book_obj.publication::putdata();
	book_obj.putdata();
	
	tape_obj.publication::putdata();
	tape_obj.putdata();
}

