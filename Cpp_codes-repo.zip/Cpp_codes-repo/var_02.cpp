/* ********************************************************************
FILE                   : var_02.cpp

PROGRAM DESCRIPTION    :  calc area of room 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <iostream>

using namespace std;

int main()
{
	int room_width {0}, room_height {0};
	
	cout <<"Enter width : " ;
	cin >> room_width;
	
	cout <<"Enter height : ";
	cin >> room_height;
	
	cout <<"area = " <<room_width * room_height<< endl;
	return 0; 
}
