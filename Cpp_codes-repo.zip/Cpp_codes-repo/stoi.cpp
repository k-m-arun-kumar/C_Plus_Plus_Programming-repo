/* ********************************************************************
FILE                   : stoi.cpp

PROGRAM DESCRIPTION    : string to integer conversion

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <iostream>   // std::cout
#include <string>     // std::string, std::stoi

using namespace std;
int main ()
{
  string str_dec = "2001, A Space Odyssey";
  string str_hex = "4003";
  

  string::size_type sz, sz1;   // alias of size_t

  int i_dec = stoi (str_dec,&sz);
  int i_dec1 = stoi (str_hex,&sz1,10);
  int i_bin = stoi (str_bin,nullptr,2);
  int i_auto = stoi (str_auto,nullptr,0);

 
  if(str_dec.compare(str_dec.substr(sz) == 0))
  {
  	cout<<endl<<str_dec<<" : matched " << str_dec.substr(sz); 
  }
  string str_compare = to_string(i_dec1);
  if(str_compare.compare(str_hex) == 0)
  {
  	cout<<endl<<str_hex<<" : matched " << str_compare; 
  }
  
  return 1;
}
