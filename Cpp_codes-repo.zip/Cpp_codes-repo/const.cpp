/* ********************************************************************
FILE                   : const.cpp

PROGRAM DESCRIPTION    : practise constant

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include <iostream>
using namespace std;

////////////////////////////////////////////////////////////////
class Distance //English Distance class
{
     private:
         int feet;
         float inches;
     public: //constructor (no args)
          Distance() : feet(0), inches(0.0)
          { 
		      cout<<"\n constructor with 0 arg - feet: "<<feet<<" & inches: "<<inches;
		  }
          //constructor (two args)
         Distance(int ft, float in) : feet(ft), inches(in)
         { 
		      cout<<"\n constructor with 2 arg - feet: "<<feet<<" & inches: "<<inches;
     	}
        Distance(int ft): feet(ft)
        {
	        cout<<"\n constructor with 1 arg - feet: "<<feet<<" & inches: "<<inches;
	        /* inches has arbitary values*/   
        }
        ~Distance()
        {
            cout<<"\n destructor - feet : "<<feet<<" & inches : "<<inches;
        }
        void getdist() //get length from user
        {
             cout << "\nEnter feet: "; cin >> feet;
             cout << "\nEnter inches: "; cin >> inches;
        }
        void showdist()  const; //display distance
        
        Distance& add_dist(const Distance&) const; 
};
//temporary variable
 Distance temp;  
void Distance::showdist() const  //display distance
{ 
     temp.feet = 200;
     temp.inches = 7.00; 
     cout << feet << "\n \'- " << inches << "\""; 
     cout << "\n temp.feet = "<< temp.feet<< "\' & temp.inches = " <<temp.inches  << "\""; 
}
//--------------------------------------------------------------
//add lengths d2 and d3
/* when object are passed as argument, default copy constructor is called as d2 = dist1 & d2 = dist2*/
//add this distance to d2, return the sum

Distance& Distance::add_dist(const Distance& d2) const
{
   
    // feet = 0; //ERROR: can�t modify this
    // d2.feet = 0; //ERROR: can�t modify d2
    temp.inches = inches + d2.inches; //add the inches
    if(temp.inches >= 12.0) //if total exceeds 12.0,
    { //then decrease inches
       temp.inches -= 12.0; //by 12.0 and
       temp.feet = 1; //increase feet
    } //by 1
    temp.feet += feet + d2.feet; //add the feet
    return temp;
}

////////////////////////////////////////////////////////////////
int main()
{
      const Distance football(300, 0);
      Distance dist1, dist3; //define two lengths
      Distance dist2(11, 6.25); //define, initialize dist2
       // football.getdist(); //ERROR: getdist() not const
       cout << "\n football = ";
       football.showdist(); //OK because showdist() is const 
      dist3= dist1.add_dist(dist2); //dist3 = dist1 + dist2
      dist3.showdist(); 
      return 0;
    /* constructor of temp,football, dist1, dist3, dist2 is are called in the order
	 and destructor of dist2, dist3, dist1,football,temp are called  in the order */
}
