/* ********************************************************************
FILE                   : distance.cpp

PROGRAM DESCRIPTION    : calc to add distance 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <iostream>
using namespace std;
////////////////////////////////////////////////////////////////
class Distance //English Distance class
{
     private:
         int feet;
         float inches;
     public: //constructor (no args)
          Distance() : feet(0), inches(0.0)
          { 
		      cout<<"\n constructor with 0 arg - feet: "<<feet<<" & inches: "<<inches;
		  }
          //constructor (two args)
         Distance(int ft, float in) : feet(ft), inches(in)
         { 
		      cout<<"\n constructor with 2 arg - feet: "<<feet<<" & inches: "<<inches;
     	}
        Distance(int ft): feet(ft)
        {
	        cout<<"\n constructor with 1 arg - feet: "<<feet<<" & inches: "<<inches;
	        /* inches has arbitary values*/   
        }
        ~Distance()
        {
            cout<<"\n destructor - feet : "<<feet<<" & inches : "<<inches;
        }
        void getdist() //get length from user
        {
             cout << "\nEnter feet: "; cin >> feet;
             cout << "\nEnter inches: "; cin >> inches;
        }
        void showdist() //display distance
        { 
		      cout << feet << "\'-" << inches << "\""; 
	    }
         void add_dist( Distance, Distance ); //declaration
};
//--------------------------------------------------------------
//add lengths d2 and d3
/* when object are passed as argument, default copy constructor is called as d2 = dist1 & d2 = dist2*/
void Distance::add_dist(Distance d2, Distance d3)
{
	
	 Distance dist4 = d2; /* object dist4 is created so default copy constructor is called*/ 
	 Distance dist5;  /* object dist5 is created so constructor with 0 arg is called*/ 
     inches = d2.inches + d3.inches; //add the inches
     feet = 0; //(for possible carry)
     if(inches >= 12.0) //if total exceeds 12.0,
     { //then decrease inches
           inches -= 12.0; //by 12.0 and
          feet++; //increase feet
      } //by 1
      feet += d2.feet + d3.feet; //add the feet
      /* d2.feet = 100;
       d2.inches = 10.1; */
}
////////////////////////////////////////////////////////////////
int main()
{
      Distance dist1, dist3(10); //define two lengths
      Distance dist2(11, 6.25); //define and initialize dist2
      dist1.getdist(); //get dist1 from user
      dist3.add_dist(dist1, dist2); //dist3 = dist1 + dist2
      //display all lengths
      cout << "\ndist1 = "; dist1.showdist();
      cout << "\ndist2 = "; dist2.showdist();
      cout << "\ndist3 = "; dist3.showdist();
      return 0;
}
