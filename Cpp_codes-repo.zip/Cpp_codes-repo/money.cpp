/* ********************************************************************
FILE                   : money.cpp

PROGRAM DESCRIPTION    : calc money conversion

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <iomanip> 
#define MAX 30

using namespace std;
long double strtomoney(string );
string moneytostr(long double);
int main()
{
	string money_str, conv_money_str;
	long double money, conv_money;
	/* enter example $1,500,450.250,350*/
	cout<<"\n Enter money in string as US dollars: ";
	cin>>money_str;
	cout<<setiosflags(ios::fixed)<<setiosflags(ios::showpoint)<<setprecision(18);	
	money = strtomoney(money_str);
	cout<<"\n money in double : "<<money;
	cout<<"\n Enter money in double = ";
	cin>>conv_money;
	conv_money_str = moneytostr(conv_money);
	cout<<"\n money in string : "<<conv_money_str; 
	return 1;
}

long double strtomoney(string money_str )
{
	
	char money_int[MAX], money_frac[MAX], money[MAX];
	size_t str_index = 0 , money_index = 0;
	bool isprecision = false;
	cout<<"\n money_str = "<<money_str<<" of len = "<<money_str.length();
	cout<<"\n INFO[01]: int = ";
	while(str_index < money_str.length())
	{
		if(money_str.at(str_index) >='0' && money_str.at(str_index) <='9') 
		{
			if(isprecision == false)
			{
		 	   	money_int[money_index]    = money_str.at(str_index);
		     	cout<<money_int[money_index] ;
		    	++money_index;
		   }
		   else 
		   {
		    	 money_frac[money_index]  = money_str.at(str_index);
	        	cout<<money_frac[money_index];
		    	++money_index;
		   }
	    }
		else if(money_str.at(str_index) =='.')
		{
			money_int[money_index] = '\0';
 		    money_index = 0; 	
		    isprecision = true;
			cout<<"\n INFO[02]: frac = ";	   
	    }
	    
		++str_index; 
	}
	if(isprecision == false)
	{
		money_int[money_index] = '\0';
	}
	else
	  	money_frac[money_index] = '\0';	

	cout<<"\n Enter money_int = "<<money_int<<", money_frac = "<<money_frac;
	strcpy(money,money_int);
	strcat(money,".");
	strcat(money,money_frac);

	cout<<"\n money in after filtering = "<<money;
	return strtold (money, NULL);
}
string moneytostr(long double conv_money)
{
	string money_str, int_money_str, frac_money_str ;
	size_t found, index_str = 0 , index_int = 0;
	long int_money,frac_money ;
	long double temp_int, temp_frac, nolead_money;
	int mod, append; 
	bool isprecision = false;
	char money_arr[MAX];
	
	money_str = to_string(conv_money);
	found = money_str.find_first_not_of("0");
	if(found == string:: npos)
	{
		cout<<"\n ERROR[01]: cannot find non '0' char ";
		return "";
	}
	money_str = money_str.substr(found);
	nolead_money = stod(money_str);
	int_money  = static_cast<long>(nolead_money);
	temp_int = static_cast<long double>(int_money);
	int_money_str = to_string(int_money);

    found = money_str.find_first_not_of(".");
	if(found != string:: npos)
	{
		isprecision = true;
		temp_frac =  nolead_money - temp_int;
		cout<<"\n INFO[06]: temp_frac = "<<temp_frac;
		frac_money_str = to_string(temp_frac);
		frac_money_str = frac_money_str.substr(2);
		mod = frac_money_str.length() % 3;
		if(mod != 0) 
		{
		   append = 3 - mod;
		   frac_money_str.append(append,'0');	
		   cout<<"\n INFO[03]: append_zero = "<<append;
		}
	}
	else
	  frac_money_str = "000000";
	cout<<"\n INFO[04]: int_money_str = "<<int_money_str<<", frac_money_str = "<<frac_money_str;
	index_str = 0;
	money_arr[index_str] = '$';
	++index_str;
	mod = int_money_str.length() % 3;

	while( index_int<int_money_str.length() )
	{
		if(index_int %3 == mod && index_int>0 )
		{
		   	money_arr[index_str] = ',';
		   	++index_str;
		   	money_arr[index_str] = int_money_str.at(index_int);
	    }
	    else
		   	money_arr[index_str] = int_money_str.at(index_int);
		++index_str;   	
		++index_int;
	}
		
    money_arr[index_str++] = '.';
    index_int = 0;
    while( index_int <frac_money_str.length() )
	{
		if(index_int %3 == 0 && index_int>0 )
		{
		   	money_arr[index_str] = ',';
		   	++index_str;
		   	money_arr[index_str] = frac_money_str.at(index_int);
	    }
	    else
		   	money_arr[index_str] = frac_money_str.at(index_int);
		++index_str;   	
		++index_int;
	}
     money_arr[index_str] = '\0';
    cout<<"\n INFO[05]: money_arr = "<<money_arr;
     money_str = money_arr;
     return money_str;
}
