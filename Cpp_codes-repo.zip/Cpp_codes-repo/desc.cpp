/* ********************************************************************
FILE                   : desc.cpp

PROGRAM DESCRIPTION    : display pattern  

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "iostream"
#include "string"
using namespace std;

int main()
{
	
	int i = 0, j= 0, l=0, num_rows, initial_cols = 0; 
	cout<<"\n rows : ";
	cin>>num_rows;
	cout<<"\n columns: ";
	cin>>initial_cols;
	
		for (i=0 ; i<num_rows;++i)
    	{
		for(j = initial_cols - i, l = 1; j >0; --j, ++l )
		{
		    cout<<l<<" ";	
		}
		cout<<endl;
	}
}

