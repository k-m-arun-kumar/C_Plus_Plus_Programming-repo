/* ********************************************************************
FILE                   : arr_obj.cpp

PROGRAM DESCRIPTION    : practise C++ coding in objects with Array

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <iostream>
using namespace std;
class Time
{
	private:
    	unsigned int hour;
	    unsigned int minute;
	    unsigned int seconds;
	    unsigned int days;
	public:
	    Time():days(0),hour(0),minute(0),seconds(0) 
		 {} 
		 Time(unsigned int day, unsigned int hr,unsigned int min, unsigned int sec = 0): days(day), hour(hr),minute(min),seconds(sec)  
		 {	
		   
		 }
		 void display() const
		 {
		 	if(days < 10)
		 	   cout<<'0';
		    cout<<days<<" days - ";
		 	if(hour < 10)
		    	cout<<'0';
		    cout<<hour<<":";
		    if(minute < 10)
		       cout<<'0';
		    cout<<minute<<":";
		    if(seconds < 10)
		       cout<<'0';
		    cout<<seconds;
		    cout<<endl;
		    return;
		 }
};

int main()
{
	Time time[3] = {{1,10,15,20}, {2,20,25,30}, {3,23,35 }};
	for(int i = 0; i< 3 ; ++i)
	{
		time[i].display();
	}
	return 1;
}
