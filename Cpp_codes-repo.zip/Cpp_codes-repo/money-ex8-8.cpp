/* ********************************************************************
FILE                   : money-ex8-8.cpp

PROGRAM DESCRIPTION    : calc money addition and subtraction 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include <iostream>
#include <cstring>
#include <string>
#include <cstdlib>
#include <iomanip> 
#define MAX 30

using namespace std;
long double strtomoney(string money_str );
string moneytostr(long double conv_money);
class bMoney
{
    private:
       long double money; // price per widget
    public:
       bMoney();
       explicit bMoney(string );
       explicit bMoney(long double );
       explicit operator long double(); 
       void getmoney();
       void putmoney();
        bMoney operator + (bMoney) const;
        bMoney operator - (bMoney) const; 
        bMoney operator * (long double) const;
        long double operator /  (bMoney) const;
        bMoney operator / (long double) const; 
		void display_money() const; 
};

 int main()
{
	string to_iterate = "y";
	long double num_widgets;
	cout<<setiosflags(ios::fixed)<<setiosflags(ios::showpoint)<<setprecision(18);
	bMoney money_oper1("$1,500.250"), money_oper2(250.0), money_result; 
	money_oper1.getmoney();
	do
	{
		cout<<"\n Enter oper1's";
	    money_oper1.putmoney();
	    cout<<"\n Enter oper2's";
	    money_oper2.putmoney();
		money_result = money_oper1 +  money_oper2;
		cout<<"\n Added";
		money_result.display_money();
		money_result = money_oper1 -  money_oper2;
		cout<<"\n Subtract";
		money_result.display_money();
		cout<<"\n Enter number of widgets - Enter in double = ";
		cin >>num_widgets;
		money_result = money_oper1 * num_widgets;  // (price per widget times number of widgets)
		cout<<"\n Total";
		money_result.display_money();
		num_widgets = money_result /  money_oper1; // (total price divided by price per widget)
		cout<<"\n Nos of widgets = "<<num_widgets;
	    money_oper1 = money_result / num_widgets;   //(total price divided by number of widgets)
	    cout<<"\n Per widget";
	    money_oper1.display_money();
    	cout<<"\n Do you want to continue ";
    	cout<<"\n Press 'y' or 'Y' to continue, any other to exit. Enter key = ";
    	cin>>to_iterate;
	} while (to_iterate.length() == 1 &&(to_iterate.at(0) =='y' || to_iterate.at(0) =='Y' ));
	return 1;
}
 
bMoney::bMoney() : money(0.0)
{
	
}
bMoney::bMoney(long double money_ld)
{
    money = money_ld;	
}

bMoney::bMoney(string money_str) 
{
	money = strtomoney( money_str );
}
bMoney::operator long double() 
{
	return money;
}
bMoney bMoney::operator + (bMoney money_oper) const
{
	long double money_added = money + money_oper.money;
	return bMoney(money_added);
}
bMoney bMoney::operator - (bMoney money_oper) const
{
	long double money_minus = money - money_oper.money;
	return bMoney(money_minus);
}
bMoney bMoney::operator * (long double num_widgets) const
{
	long double total_price = money * num_widgets;
	return bMoney(total_price);
}
long double bMoney::operator /  (bMoney price_perwidget) const
{
    long double num_widgets = money / price_perwidget.money;
	return num_widgets;	
}
bMoney bMoney::operator / (long double num_widgets) const
{
	long double price_perwidget = money / num_widgets;
	return bMoney(price_perwidget);
}
void bMoney::getmoney()
{
	
    string conv_money_str, get_money;
	cout<<"\n Enter money in double = ";
	cin>>get_money;
	money = stold(get_money);
	conv_money_str = moneytostr(money);
	cout<<"\n INFO[08]: money in string : "<<conv_money_str; 	
	
}
void bMoney::putmoney() 
{
	/* enter money such as  $1,500,450.250,350*/
    string money_str;
	cout<<" price in string as US dollars: ";
	cin>>money_str;
		
	money = strtomoney(money_str);
	cout<<"\n INFO[07]: money in double : "<<money;
}
void bMoney::display_money()  const
{
	cout<<" Price = "<<money;
	return ;
}
long double strtomoney(string money_str )
{
	
	char money_int[MAX], money_frac[MAX], money[MAX];
	size_t str_index = 0 , money_index = 0;
	bool isprecision = false;
	cout<<"\n money_str = "<<money_str<<" of len = "<<money_str.length();
	cout<<"\n INFO[01]: int = ";
	while(str_index < money_str.length())
	{
		if(money_str.at(str_index) >='0' && money_str.at(str_index) <='9') 
		{
			if(isprecision == false)
			{
		 	   	money_int[money_index]    = money_str.at(str_index);
		     	cout<<money_int[money_index] ;
		    	++money_index;
		   }
		   else 
		   {
		    	 money_frac[money_index]  = money_str.at(str_index);
	        	cout<<money_frac[money_index];
		    	++money_index;
		   }
	    }
		else if(money_str.at(str_index) =='.')
		{
			money_int[money_index] = '\0';
 		    money_index = 0; 	
		    isprecision = true;
			cout<<"\n INFO[02]: frac = ";	   
	    }
	    
		++str_index; 
	}
	if(isprecision == false)
	{
		money_int[money_index] = '\0';
	}
	else
	  	money_frac[money_index] = '\0';	

	cout<<"\n Enter money_int = "<<money_int<<", money_frac = "<<money_frac;
	strcpy(money,money_int);
	strcat(money,".");
	strcat(money,money_frac);

	cout<<"\n money in after filtering = "<<money;
	return strtold (money, NULL);
}


string moneytostr(long double conv_money)
{
	string money_str, int_money_str, frac_money_str ;
	size_t found, index_str = 0 , index_int = 0;
	long int_money,frac_money ;
	long double temp_int, temp_frac, nolead_money;
	int mod, append; 
	bool isprecision = false;
	char money_arr[MAX];
	
	money_str = to_string(conv_money);
	found = money_str.find_first_not_of("0");
	if(found == string:: npos)
	{
		cout<<"\n ERROR[01]: cannot find non '0' char ";
		return "";
	}
	money_str = money_str.substr(found);
	found = money_str.find_first_of(".");
	if(found != string:: npos)
	{
		isprecision = true;
		int_money_str = money_str.substr(0,found);
		frac_money_str = money_str.substr(found + 1);
	    mod = frac_money_str.length() % 3;
		if(mod != 0) 
		{
		   append = 3 - mod;
		   frac_money_str.append(append,'0');	
		   cout<<"\n INFO[03]: append_zero = "<<append;
		}
	}
	else
	  frac_money_str = "000000"; 
	
	/* COMMENTED due to fraction part of money ie temp_frac is not precise */
	/* nolead_money = stod(money_str);
	int_money  = static_cast<long>(nolead_money);
	temp_int = static_cast<long double>(int_money);
	int_money_str = to_string(int_money);

    found = money_str.find_first_not_of(".");
	if(found != string:: npos)
	{
		isprecision = true;
		temp_frac =  nolead_money - temp_int;
		cout<<"\n INFO[06]: temp_frac = "<<temp_frac;
		frac_money_str = to_string(temp_frac);
		frac_money_str = frac_money_str.substr(2);
		mod = frac_money_str.length() % 3;
		if(mod != 0) 
		{
		   append = 3 - mod;
		   frac_money_str.append(append,'0');	
		   cout<<"\n INFO[03]: append_zero = "<<append;
		}
	}
	else
	  frac_money_str = "000000"; */
	  
	  
  	cout<<"\n INFO[04]: int_money_str = "<<int_money_str<<", frac_money_str = "<<frac_money_str;
	index_str = 0;
	money_arr[index_str] = '$';
	++index_str;
	mod = int_money_str.length() % 3;

	while( index_int<int_money_str.length() )
	{
		if(index_int %3 == mod && index_int>0 )
		{
		   	money_arr[index_str] = ',';
		   	++index_str;
		   	money_arr[index_str] = int_money_str.at(index_int);
	    }
	    else
		   	money_arr[index_str] = int_money_str.at(index_int);
		++index_str;   	
		++index_int;
	}
		
    money_arr[index_str++] = '.';
    index_int = 0;
    while( index_int <frac_money_str.length() )
	{
		if(index_int %3 == 0 && index_int>0 )
		{
		   	money_arr[index_str] = ',';
		   	++index_str;
		   	money_arr[index_str] = frac_money_str.at(index_int);
	    }
	    else
		   	money_arr[index_str] = frac_money_str.at(index_int);
		++index_str;   	
		++index_int;
	}
     money_arr[index_str] = '\0';
    cout<<"\n INFO[05]: money_arr = "<<money_arr;
     money_str = money_arr;
     return money_str;
}


