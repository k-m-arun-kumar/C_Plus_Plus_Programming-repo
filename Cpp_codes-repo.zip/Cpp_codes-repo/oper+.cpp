/* ********************************************************************
FILE                   : oper+.cpp

PROGRAM DESCRIPTION    : operator +

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <iostream>

using namespace std;
class Distance
{
	private:
		int feet;
		float inches;
	public:
	  Distance() : feet(0), inches(0.0)
	  {
	  }
	  Distance (int ft, float inch) : feet(ft), inches(inch)
	  {
	  	cout<<"\n INFO[01]: constructor in 2 arg: feet = "<<feet<<", inches = "<<inches;
	  }
	  void get_distance()
	   {
	   	   cout<<"\n Enter feet : ";
	   	   cin>>feet;
	   	   cout<<"\n Enter inches : ";
	   	   cin>>inches;
	   } 
	   void disp_distance()	const
	   {
	   	  cout << feet << "\'-" << inches << '\"';
	   }
	   Distance operator + (Distance) const;
	   
};

Distance Distance::operator + (Distance d2) const
{
	int ft = feet - d2.feet;
	float inch = 0.0, floatinches;
	if(inches<d2.inches)
	{
		 --ft;
		 inch = 12.0;
	}
	inch += inches - d2.inches;
	 floatinches = ft *12 + inch;
	 if(floatinches<0.0f)
	 {
	 	cout<<"\n ERROR[01]: Distance cannot be negative";
	 	exit(1);
	 } 
     return Distance(ft, inch);
}

int main()
{
	Distance d1, d3;
	Distance d2(10 , 11.25);
	
	d1.get_distance();
	d3 = d1 + d2;
	cout<<"\n d3 = ";
	d3.disp_distance();
	return 1;
}
