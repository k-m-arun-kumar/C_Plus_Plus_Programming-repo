/* ********************************************************************
FILE                   : move_const_08.cpp

PROGRAM DESCRIPTION    : 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include <iostream>
#include <string>
using namespace std;

class Account
{
	private:
		 string name;
		double balance;
	public:
	  Account(const string source_name = "NA", const double source_balance = 32500 ) 
	    : name(source_name), balance(source_balance)
		{
			cout<<"In 2 arg constructor: name: "<<name<<" has balance: "<<balance << endl;
	    } 
	    
	  ~Account()
	  {
	  	cout<<"In destructor: name "<< name <<" account deleted"<< endl;
      }
	  Account(const Account &source)  
	    : Account(source.name, source.balance)
	  {
	  	  cout<<"In copy constructor: name: "<<name<<" has balance: "<<balance << endl;
	  }
	  Account(Account &&source)  noexcept
	    : Account(source.name, source.balance)
	  {
	  	  cout<<"In move constructor: name: "<<name<<" has balance: "<<balance << endl;
	  } 
	  void set_name(const string source_name = "XXXXX", const double source_balance = 5000) 
	  {
	  	  name = source_name;
	  	  balance = source_balance;
	  }
	  string get_name()
	  {
	  	 return name;
	  }
	  double get_balance()
	  {
	  	 return balance;
	  }
	  
};

void create_account(string name_val = "None", double balance_val = 7500)
{
	Account kanna_account{name_val, balance_val};	
	cout<<"In create_account: name : "<<kanna_account.get_name() << " has balance : "<<kanna_account.get_balance()<<endl;
}
Account return_account(string name_val, double balance_val)
{
	Account temp_account{name_val, balance_val};	
	cout<<"In return_account: name : "<<temp_account.get_name() << " has balance : "<<temp_account.get_balance()<<endl;
	return temp_account;
}
void get_account(Account source)
{
	cout<<"In get_account: name : "<<source.get_name() <<" has balance : "<<source.get_balance()<<endl;
}
int main()
{
	Account arun{return_account("Arun", 2500 )};	
	create_account("Kanna");
    Account kumar{"Kumar", 10000};	
	Account murugan{kumar};
	
	get_account(arun);
	murugan.set_name("Murugan");
	
	return 0;
}
