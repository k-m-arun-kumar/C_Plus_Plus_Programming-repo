/* ********************************************************************
FILE                   : cpp_str_05.cpp

PROGRAM DESCRIPTION    : encrypt and then decrypt message 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <iostream>
#include <string>
#include <cctype>
using namespace std;

int main()
{
	string alphabet {"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"};
    string key  {"XZNLWEBGJHQDYVTKFUOMPCIASRxznlwebgjhqdyvtkfuompciasr"};
    string secret_message;
    cout <<"Enter message to be encrypted : ";
    getline(cin, secret_message);
    
    string encrypted_message;
    for(char secret_char : secret_message)
    {
        if(isalpha(secret_char))
        {
           size_t position;
           position = alphabet.find(secret_char);
           if(position == string::npos)	
		   {
		   	   cout<<"ERR 01: plain alphabet: " <<secret_char<< " to encrypt is not found"<<endl;
		   	   encrypted_message += secret_char;
		   	   break;
		   }
		   else
		   {
		       encrypted_message += key.at(position);
	       }
        }
        else
        {
		    encrypted_message += secret_char;
		}
    }
	cout<<"Encrypted message : "<< encrypted_message<<endl;
	secret_message.clear();
	for(char secret_char : encrypted_message)
    {
        if(isalpha(secret_char))
        {
           size_t position;
           position = key.find(secret_char);
           if(position == string::npos)	
		   {
		   	   cout<<"ERR 01: encrypted alphabet: " <<secret_char<< " to plain is not found"<<endl;
		   	   secret_message += secret_char;
		   }
		   else
		   {
		       secret_message += alphabet.at(position);
	       }
        }
        else
        {
		    secret_message += secret_char;
		}
	}
	cout<<"Decrypted message : "<< secret_message; 
	return 0;
}
