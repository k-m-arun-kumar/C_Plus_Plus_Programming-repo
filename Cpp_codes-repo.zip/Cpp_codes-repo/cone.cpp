/* ********************************************************************
FILE                   : cone.cpp

PROGRAM DESCRIPTION    : cone display pattern

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <iostream>
#include <string>
#include <process.h>
using namespace std;

int main()
{
	int row_count = 0, row_num, col_count = 0, col_num, disp_min, disp_max;
	string to_iterate;
	char ch;
	
	do{
	cout<<"\n Enter row: ";
	cin>>row_num;
	cout<<"\n Enter col: ";
	cin>>col_num;
	disp_min = ( col_num % 2)?  col_num / 2 + 1: col_num / 2  ;
	disp_max = ( col_num % 2)?  disp_min: disp_min + 1 ;
	cout<<"\n Initial disp_min - "<<disp_min<<" & disp_max - "<<disp_max;
    if(row_num <=disp_min ) 
    {
	cout<<endl;
	for(row_count =1 ; row_count<=row_num; ++row_count )
	{
		for(col_count= 1; col_count <=col_num;  ++col_count)	
		{
			ch = (col_count >=disp_min && col_count <= disp_max ) ? 'X': '-';
			cout<<ch;			 
		}
		cout<<endl;
		--disp_min;
		++disp_max;
	} 
    }
    else
     cout<<"\n ERROR[01] : row_num[" <<row_num<< "] > disp_min ["<<disp_min<<"]";
	cout<<"\n Do you want to continue(y/n) : enter -  ";
	cin>>to_iterate;
    } while(to_iterate.length() == 1 && (to_iterate.at(0) == 'y' || to_iterate.at(0) == 'Y'));
	exit(0);
}
