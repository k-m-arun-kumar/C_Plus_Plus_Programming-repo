/* ********************************************************************
FILE                   : time_add.cpp

PROGRAM DESCRIPTION    :  calc of time addition 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <iostream>
using namespace std;
class Time
{
	private:
    	unsigned int hour;
	    unsigned int minute;
	    unsigned int seconds;
	    unsigned int days;
	public:
	    Time():hour(0),minute(0),seconds(0),days(0) 
		 {} 
		 Time(unsigned int hr,unsigned int min, unsigned int sec, unsigned int day): hour(hr),minute(min),seconds(sec), days(day)  
		 {	
		   
		 }
		 void gettime()
		 {
		 	cout<<"\n Enter time in hour    = ";
		 	cin>>hour;
		 	cout<<"\n Enter time in minute  = ";
		 	cin>>minute;
		 	cout<<"\n Enter time in seconds = ";
		 	cin>>seconds;
		 	return;
		 }
		 void display() const
		 {
		 	if(days < 10)
		 	   cout<<'0';
		    cout<<days<<" days - ";
		 	if(hour < 10)
		    	cout<<'0';
		    cout<<hour<<":";
		    if(minute < 10)
		       cout<<'0';
		    cout<<minute<<":";
		    if(seconds < 10)
		       cout<<'0';
		    cout<<seconds;
		    
		    return;
		 }
		 Time operator + (Time T2) const;
		 Time operator - (Time T2) const;
		 Time operator ++ () 
		 {
		      if(++hour > 23)
		      {
		          hour -=24;
		      	  ++days;
			  }
		      return Time(hour,minute, seconds, days);     
		 }
		 Time operator ++ (int)  //postfix ++
		{
			unsigned int hour24 = hour;
			unsigned int day24 = days;
			if(hour++ > 23) 
	        {
	         	++days;
	        	hour -=24;
	        } 
		    return Time(hour24++,minute, seconds, day24);  
		}
		Time operator * (float); 
};
Time Time::operator + (Time T2) const
{
	unsigned int hour24 =0;
    unsigned int min24 = 0;
	unsigned int sec24 = 0;
	unsigned int days24 = 0;
	sec24 = seconds + T2.seconds;
	if(sec24 >=60)
	{
		min24 = 1;
		sec24 -=60;
	}
	 min24 += minute + T2.minute;
    if(min24 >=60)
	{
		hour24 = 1;
		 min24 -=60;
	}
	 hour24 += hour + T2.hour;
	 if(hour24 > 23) 
	 {
	 	++days24;
	 	hour24 -=24;
	 } 
		     
	 return Time(hour24,min24, sec24, days24);   
}
Time Time::operator - (Time T2) const
{
	unsigned int days24 = days;
    unsigned int hour24 =hour;
    unsigned int min24 = minute;
    unsigned int sec24 = 0;
  
    long minurend_sec = 0, subtractend_sec=0;
	
	minurend_sec = seconds + minute *60 + hour * 3600 + days * 24 * 3600;
	subtractend_sec = T2.seconds + T2.minute *60 + T2.hour * 3600 + T2.days * 24 * 3600;
	if(minurend_sec - subtractend_sec < 0 )
	{
		cout<<"\n ERROR[01]: total seconds diff cannot be negative ";
		exit(0);
	}
	if(seconds < T2.seconds)
	{
		--min24;
	 	sec24 = 60;
	 	 	
	}
	sec24 += seconds - T2.seconds;
	if(min24 <  T2.minute )
	{
		--hour24;
		min24 += 60;
	}
	min24 -=  T2.minute;
	if(hour24 < T2.hour )
	{
		--days24;
		hour24 += 24;
	}
	hour24 -= T2.hour; 
	days24 -= T2.days;
	     
	return  Time(hour24,min24, sec24, days24 );  	
}
Time Time::operator * (float factor)
{
    unsigned int days24 = 0;
    unsigned int hour24 =0;
    unsigned int min24 = 0;
    unsigned int sec24 = 0;
    unsigned int mul = 0; 
    mul = seconds * factor;
    sec24 = mul % 60;
    min24 = mul / 60;
    mul = minute * factor;
    min24 += mul % 60;
    hour24 = mul / 60;
    mul = hour * factor;
    hour24 += mul % 24;
    days24 = mul / 24;
    mul = days * factor;
    days24 += mul;
    return Time(hour24,min24, sec24, days24 );
}
int main()
{
	Time t1, t3;
    const Time t2 = {5,30,30,0};
    
    float mul;
    
	t1.gettime();
	t3 = t1 + t2;
	cout<<"\n t3 = t1 + t2 = ";
	t3.display();
	t3 = t1 - t2;
	cout<<"\n t3 = t1 - t2 = ";
	t3.display();
	/* if multiple factor is integer, answer is correct, ie mul = 3.0. for float ie  mul = 3.6,
	   answer is incorrect, ref https://rechneronline.de/add-time/multiplication-division.php or
	   http://www.datedial.com/datMultiply_Divide_Time.asp */
	cout<<"\n Enter multiple factor : ";
	cin>>mul;
	t3 = t1 * mul;
	cout<<"\n t3 = t1 * mul = ";
	t3.display(); 
	cout<<"\n ++t1 = ";
	++t1;
	t1.display();
	t3 = ++t1;
	cout<<"\n t3 = ++t1 = ";
	t3.display();
	cout<<"\n t1++ = ";
	t1++;
	t1.display();
	t3 = t1++;
	cout<<"\n t3 = t1++ ";
	cout<<"\n ------------ \n t1 = ";
	t1.display();
	cout<<"\n t3 = ";
	t3.display();
	t3 = t1++;
	cout<<"\n t3 = t1++ ";
	cout<<"\n ------------ \n t1 = ";
	t1.display();
	cout<<"\n t3 = ";
	t3.display();
	return 1;
}
