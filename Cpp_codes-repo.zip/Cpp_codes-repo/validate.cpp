/* ********************************************************************
FILE                   : validate.cpp

PROGRAM DESCRIPTION    :  validate a given number and display a pattern 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "iostream"
#include "string"

#define MIN_ROW          04
#define MAX_ROW          10
#define MIN_COL          02
#define MAX_COL          20
#define COMM_DIFF        01
#define ROW_NUMERIC      01
#define ROW_NUMERIC_DIFF 01

using namespace std;
class pattern
{
public:
        unsigned int num_rows;
	    unsigned int initial_cols;
	    char pattern_order;
	    unsigned int midrow;
	    unsigned int midrow_col;
public: 	    
 int calc_term(unsigned int initial_value, unsigned int terms );
 unsigned int calc_term();
int validate();
int disp_pattern_input();
int pattern_display();
int asc_pattern(unsigned int rows_num, unsigned int col_initial);
int desc_pattern(unsigned int rows_num, unsigned int col_initial);
};
unsigned int pattern::calc_term()
{
 	unsigned int middle_row;
 	middle_row = ( num_rows % 2 == 0) ? num_rows / 2: (num_rows / 2 ) + 1;
 	return middle_row;
 }
int pattern::validate()
{
	   
    int mid_row, temp, term_value, min_max_range;   
	
    temp = initial_cols ;
       	 switch(pattern_order) 
	        {
		    	case 'a':
		    		term_value = calc_term( temp, num_rows );
		    		if( term_value > (MAX_COL) || !(temp >= (MIN_COL) &&  temp <= (MAX_COL )))
                    {
                       cout<<"\n ERROR[05]: Entered column data ["<<temp<<"] is out of range ["<< (MIN_COL) <<","<<( MAX_COL)<< "]";
					   cout<<"\n or for ASC pattern last term's value ["<<term_value<<") > MAX_COL ["<<(MAX_COL)<<"]";
					   min_max_range = (MAX_COL) - (num_rows - 1) *(COMM_DIFF);
					   
 					   cout<<"\n INFO[06]: Valid range ["<<(MIN_COL)<<","<<min_max_range<<" ] for row data ["<<num_rows<<"]";	
                    }  
					else 
					{
					    initial_cols = temp;
                        cout <<"\n INFO[01]: Entered initial columns : "<<initial_cols; 
                        midrow_col = calc_term(initial_cols, midrow);
                        return 0;	
					}         	                   
                   	break;
		        case 'd':
		        	term_value = calc_term( temp, num_rows );
		            if(num_rows > temp  || term_value < (MIN_COL) || !( temp >= (MIN_COL) && temp <= (MAX_COL)))
		            {
		                 min_max_range	 = (MIN_COL) + (num_rows - 1)*(COMM_DIFF);
					    cout<<"ERROR[12]: Entered column data ["<<temp<<"] is out of range["<< (MIN_COL) <<","<<( MAX_COL)<< "])" ;
					    cout<<"\n or for DESC pattern last term's value ["<<term_value<<"] < MIN_COL ["<<(MIN_COL)<<"]";
					    cout<<"\n Valid col data  with range ["<<min_max_range<<","<<(MAX_COL)<< "] for row data ["<<num_rows<<"]";
				    }
			       else 
			       {
			        	initial_cols = temp;
			        	cout <<"\n INFO[03]: Entered initial columns : ["<<initial_cols<<"]"; 
           	            midrow_col = calc_term(initial_cols, midrow);
           	            return 0;	
				    }
				    break;											  					   
                case 'x': 
                    term_value = calc_term( temp, midrow );
                    if( term_value > (MAX_COL ) ||!(temp >= ( MIN_COL) && temp <= (MAX_COL ) ))
           	        {
           	           	cout<<"\n ERROR[21]: Entered column data ["<<temp<<"] is out of range["<<( MIN_COL) <<","<<( MAX_COL)<< "]";
           	            cout<<"\n or for ASC-DES pattern max term's value ["<<term_value<<"] > MAX_COL ["<<(MAX_COL)<<"]";
           	            min_max_range = (MAX_COL) - (midrow - 1) *(COMM_DIFF) ;
					    cout<<"\n INFO[07]: Valid range ["<<(MIN_COL)<<","<<min_max_range<<"] for row data ["<<num_rows<<"]";	
           	        } 
					else
					{			
					    initial_cols = temp;
           	            cout <<"\n INFO[04]: Entered initial columns : "<<initial_cols; 
           	            midrow_col = calc_term(initial_cols, midrow);
           	            return 0;
				    }
                    break;                          	 
                case 'z':                           	 
                    mid_row = calc_term();
                    term_value = calc_term( temp, midrow );
				    if(mid_row > temp || term_value <(MIN_COL) || !( temp >= (MIN_COL ) && temp <= ( MAX_COL)  ))
				    {
				    	cout<<"\n ERROR[21]: Entered column data ["<<temp<<"] is out of range["<<( MIN_COL) <<","<<( MAX_COL)<< "] ]";
           	            cout<<"\n or for DES-ASC pattern max term's value ["<<term_value<<"] > MAX_COL ["<<(MAX_COL)<<"]";
           	            min_max_range	 = (MIN_COL) + (midrow - 1)*(COMM_DIFF);
					   cout<<"\n Valid col data  with range ["<<min_max_range<<","<<(MAX_COL)<< "] for row data ["<<num_rows<<"] ";
				    }
				    else 
           	        {
				      	initial_cols = temp;
           	            
                        cout <<"\n INFO[05]: Entered initial columns : "<<initial_cols; 
           	            midrow_col = calc_term(initial_cols, mid_row);
           	            return 0;	
				    }
				    break;
					default:
					   cout<<"\n ERROR[13]: Invalid pattern format : "<<pattern_order;				   
			}
			return 1;
}
int pattern::disp_pattern_input()
{
	cout<<"\n Pattern Setting \n ==============================";
	
	cout<<"\n Entered Number of rows            : "<<num_rows;
    	cout<<"\n Entered Number of initial columns : "<<initial_cols;
    	cout<<"\n Mid row                           : "<<midrow;
    	cout<<"\n Midrow's column                   : "<<midrow_col;
    	return 0;
	
	return 1;
}	
int pattern::pattern_display()
	{
	    unsigned int temp;
		cout<<"\n \n Display Pattern";
	    cout<<"\n======================\n";
	    switch(pattern_order)
	    {
	    	case 'a':
	    	   this->asc_pattern(num_rows, initial_cols) ;
               break;
        	case 'd':
               this->desc_pattern(num_rows, initial_cols);
			   break;
			case 'x':
			   this->asc_pattern(midrow, initial_cols) ;
			   if(num_rows % 2 == 0)	
			      this->desc_pattern(num_rows - midrow, midrow_col );
			    else
				  this->desc_pattern(num_rows - midrow, midrow_col - 1 );	
			    break;
			case 'z':
				this->desc_pattern(midrow, initial_cols) ;
			    if(num_rows % 2 == 0)	
			      this->asc_pattern(num_rows - midrow, midrow_col );
			    else
				  this->asc_pattern(num_rows - midrow, midrow_col + 1 );		
			   break;      
        	default:
        		 cout<<"\n ERROR[07]: Invalid pattern order key - "<<pattern_order;  
        		 return 1; 			     	
		}
		return 0;
    }
    
    int pattern::asc_pattern(unsigned int rows_num, unsigned int col_initial)
   {  
	int outer_loop_count = 0, inner_loop_count = 0, cur_cell_val = 0;
	
   	for(outer_loop_count=0; outer_loop_count<rows_num ; ++outer_loop_count)
    { 
	    for(inner_loop_count =0, cur_cell_val = (ROW_NUMERIC); inner_loop_count < outer_loop_count + col_initial ; ++inner_loop_count, cur_cell_val = cur_cell_val+ (ROW_NUMERIC_DIFF ))
	       cout<<cur_cell_val<<" ";
	    cout<<endl; 
    } 	
	return 0;
   }


int pattern::desc_pattern(unsigned int rows_num, unsigned int col_initial)
{
	int outer_loop_count = 0, inner_loop_count = 0, cur_row_col = 0;
	
    for(outer_loop_count = 0; outer_loop_count<rows_num; ++outer_loop_count)
	{
 	    for(inner_loop_count = col_initial - outer_loop_count, cur_row_col = 1;  inner_loop_count> 0; --inner_loop_count, ++cur_row_col )
 	       cout<<cur_row_col<<" ";
        cout<<endl;
	}
	return 0;
}

int pattern::calc_term(unsigned int initial_value, unsigned int terms )
{
	int term_value ;
    switch(pattern_order)
	{
	  	case 'a':
	  	case 'x':	
	   	  term_value = initial_value + ( (terms - 1) * (COMM_DIFF));
          break;
        case 'd':
        case 'z':	
          term_value = initial_value + ( (terms - 1) * -(COMM_DIFF));
		  break;
	   	default:
          cout<<"\n ERROR[01]: Invalid pattern format key - "<<pattern_order; 		  
		 return 0;     	
	}	
	return term_value;
}
int main()
{

  string to_iterate;
  pattern pat;
  do
  { 
    cout<<"\n Enter pattern format : ";
	cin>>pat.pattern_order;
	cout<<"\n Enter row : ";
	cin>>pat.num_rows;
	cout<<"\n Enter col : ";
	cin>>pat.initial_cols;
	pat.midrow = pat.calc_term();
	if(!pat.validate()) 
	{
		
	    pat.pattern_display();
    }
    pat.disp_pattern_input();
	 cout<<"\n Press key 'y' or 'Y' to continue or any other key(s) to exit : Enter key -  ";
	 cin>>to_iterate;		    	   
  }
  while(to_iterate.length() == 1 && (to_iterate.at(0) == 'y' || to_iterate.at(0) == 'Y')); 
   return 1;			    
}
	
	
