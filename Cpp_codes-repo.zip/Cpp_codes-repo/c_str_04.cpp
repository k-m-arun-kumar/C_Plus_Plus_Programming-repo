/* ********************************************************************
FILE                   : c_str_04.cpp

PROGRAM DESCRIPTION    : practise getline function 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <iostream>

using namespace std;

int main()
{
	const char hello_msg [] {"Hello"};
	char name [30] {};
	
	cout <<hello_msg << " " << "Mr." << name <<endl;
	
	cout <<"Enter your full name : ";
	cin.getline(name, 10);
	cout <<hello_msg << " " << "Mr." << name <<endl;
	
	return 0;	
}
