/****************************************************************************************
FILE                  : pattern.cpp

PURPOSE               : get user pattern format key, number of rows for the pattern and number of columns in the first row for the pattern and validate it, 
                        if any invalid data is feed then give information on valid pattern attribute's data can have. if all pattern attribute datas are correct, 
						then display the pattern according to given pattern attribute datas. Program is interactive.  

DESCRIPTION           : 1: Ask for user to iterate. use key 'y' or 'Y' to continue to iterate or any other key(s) to exit the iteration. if user presses 'y' or 'Y',
                           then go to step 2, else go to step 13
                        2: if invalid pattern format key in attribute's data is feed, goto step 1. else goto step 3 
						3: valid pattern format key in attribute's data has been feed by keyboard, go to step 4
						4: get number of rows for the pattern in attribute data input from user by keyboard, and validate it. 
					    5: invalid number of rows for the pattern in attribute's data is feed, it gives information of valid range that number of rows for the pattern 
						   in attribute's data can have. Ask for user to either to continue to iterate or not. goto step 6.
					    6: if the user presses key 'y' or 'Y' to continue to correct number of rows pattern in attribute's data, then goto step 4. else goto step 13
						7: Valid number of rows for the pattern in attribute's data is feed, go to step 8.
						8: Get number of columns in the first row for the pattern in attribute's data input from user by keyboard, and validate it.
						9: if invalid number of columns in the first row for the pattern in attribute's data is feed, it gives information of valid range that number of columns in the first row 
						   for the pattern in attribute's data can have for the given pattern format key and number of rows for the pattern in attribute's data. Ask for user to either to continue 
						   to iterate or not. goto step 10.
					    10: if the user presses key 'y' or 'Y' to continue to correct number of columns in the first row for the pattern in attribute's data, then goto step 8. else goto step 13 
					    11: Valid number of columns in the first row for the pattern attribute's data had been feed, go to step 12.
					    12: display the pattern according to pattern format key, number of rows for the pattern and number of columns in the first row for the pattern in attribute's data,
					    13: exit the program.						                    

INPUT          	      : use key 'a' or 'A' for ascending pattern format, use key 'd' or 'D' for descending pattern format,
                        use key 'x' or 'X' for ascending then descending pattern format, use key 'z' or 'Z' for descending then ascending pattern format.
						use key 'y' or 'Y' to continue to iterate or any other key(s) to exit the application, 
						input data from keyboard - Pattern format key, number of rows in the pattern, and number of columns in the first row in the pattern.    

OUTPUT    EXAMPLE-    : display pattern for ascending pattern format, for number of rows is 3 and number of columns in the first row = 3
                         1 2 3
                         1 2 3 4
						 1 2 3 4 5 
						 
						display pattern for descending pattern format, for number of rows = 3 and number of columns in the first row = 5
						 1 2 3 4 5
						 1 2 3 4
						 1 2 3
						 
						 display pattern for ascending then descending pattern format, for number of rows = 5, and number of columns in the first row = 3
						 1 2 3
						 1 2 3 4 
						 1 2 3 4 5
						 1 2 3 4
						 1 2 3 
						 
						 display pattern for ascending then descending pattern format, for number of rows = 6,number of columns in the first row  = 3;
						 1 2 3
						 1 2 3 4 
						 1 2 3 4 5
						 1 2 3 4 5
						 1 2 3 4
						 1 2 3
						 						 
						 display pattern for descending then ascending pattern format, for number of rows = 5, number of columns in the first row = 5
						  1 2 3 4 5
						  1 2 3 4
						  1 2 3
						  1 2 3 4
						  1 2 3 4 5
						  
						display pattern for ascending then descending pattern format, for number of rows = 6, number of columns in the first row = 3;
						 1 2 3 4 5
						 1 2 3 4 
						 1 2 3 
						 1 2 3 
						 1 2 3 4
						 1 2 3 4 5 
						 
						Function operation returns 0 on success, else returns non zero integer value for failure operation, invalid data operation or actual valid data.

AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :

NOTE  ENVIRONMENT     : Developed and Tested in Dev-C++ version 5.11 32-bit IDE.
                        Compiler is TDM-GCC 4.9.2 32 bit Release configured with ISO C++11 Standard.  
      DESIGN          : 1: used lesser middle row value if  number of rows of the pattern in attribute's data is even.
	                    2: cannot use + or - sign for integer data for number of rows in the pattern and number of column's in first row in pattern's data.                 

CHANGE LOGS           :

CREATED DATE & LAST MODIFIED DATE      : 24th August 2017 & 26th August 2017.

*****************************************************************************************/
#include "iostream"
#include "string"
#include "cctype"
/* be careful in change the CONSTANT defination */
#define MIN_ROW          04   /* minimum limit value of number of rows attribute must have to display in pattern format */
#define MAX_ROW          10   /* maximum limit value of number of rows attribute must have to display in pattern format */
#define MIN_COL          02   /* minimum limit value of column to display in pattern format */
#define MAX_COL          20   /* maximum limit value of column to display in pattern format */

#define ROW_NUMERIC      01   /* initial character display value at first column of new row in pattern format */
#define ROW_NUMERIC_INCR 01   /* numeric factor to display in pattern format for next column in a row */
#define INITIAL_ROW      07   /* At start, initial value that number of rows attribute to display in pattern format */
#define INITIAL_COL      04   /* At start, initial value that number of columns in first row  attribute to display in pattern format */
const char initial_pattern[] = "a"; /* At start, initial pattern format key to display. used character array, as I cannot find a solution for conversion from char to string,
                                      so I use character array of length 1, excluding null character at the end of array */
#define DEBUG            00   /* set 0 to stop debug or any non 0 integer data to debug  */

/* dont change these parameters: BEGIN */
#define COMM_DIFF        01   /* common difference in numeric arthimetric progression */
#define DEFAULT_ROW      07   /* if recoverable error occurs, then set value that number of rows attribute to display in pattern format */
#define DEFAULT_COL      04   /* if recoverable error occurs, then set value that number of columns in first row  attribute to display in pattern format  */ 
const char default_pattern_key[] = "a";  /* if recoverable error occurs, then set pattern format key to display, 
                                       as I cannot find a solution for conversion from char to string, so I use character array of length 1, excluding null character at the end of array */ 
 /* dont change these parameters: END */
 
using namespace std;
class Pattern
{
	private:
		unsigned int num_rows;        /* number of rows attribute must have to display in pattern format */
	    unsigned int firstrow_col;    /* number of columns in first row  attribute to display in pattern format */
	    char pattern_format;           /* pattern format key to display */
	    unsigned int midrow;          /* middle row's value used mainly for ascending then descending and descending then ascending pattern format
		                                  eg num_rows = 5, then midrow = 3, and num_rows = 8, then midrow = 4 */
	    unsigned int midrow_col;      /* number of columns present for middle row (ie) midrow attribute in the pattern format, mainly for ascending then descending 
		                                 and descending then ascending pattern format  */
	public:	                                 
		Pattern(string str_initial_patternkey, unsigned int initial_row, unsigned int initial_col);
	    int pattern_input();
		int disp_pattern_input();
		int pattern_display();	
		int default_pattern();
		
	private:
        unsigned int calc_term();
 	    int calc_term(unsigned int initial_value, unsigned int terms, char oper);	
		int asc_pattern(unsigned int rows_num, unsigned int col_initial);  
		int desc_pattern(unsigned int rows_num, unsigned int col_initial);    
	    int validate_row_data(string row_data);
	    int set_row_data(unsigned int valid_row_data);
		int input_row_data();
		int input_col_data();
		int validate_col_data(string col_data);
		int set_col_data(unsigned int valid_col_data);
		int validate_patternkey_data(string pattern_key_data);    
		int input_patternkey_data(); 
		int disp_pattern_format_key();		
};
		                  
/*--------------------------------------------------------------
FUNCTION NAME  : Pattern()

PURPOSE        : Initilialize pattern attribute's data. 

DESCRIPTION    :  Initialize pattern attributes with initial values.
                 if feed data's is/are invalid, then default value for pattern attribue is set.

INPUT          : initial values for the pattern format key number of rows in the pattern, and number of columns for the first row    

OUTPUT         : initialize pattern attributes

NOTE           : constructor for Class Pattern,

KNOWN BUGS     :
--------------------------------------------------------------*/	
Pattern::Pattern(string str_initial_patternkey, unsigned int initial_row, unsigned int initial_col ) 		
		{
		   string str_row, str_col;
		   /* convert to string for given initial row and initial column */
		   str_row = to_string(initial_row);
		   str_col = to_string(initial_col);
		   /* validate the pattern attribute's data' */  
		   if(validate_patternkey_data(str_initial_patternkey) || validate_row_data(str_row) || validate_col_data(str_col) )
		   {
		   	    /* if any of pattern attributes is invalid, then set default and safe parameters */ 
		   	    default_pattern();
				cout<<"\n ERROR[17]: Invalid initial values in any one or more attribute(s) "; 
				cout<<"\n Initial Pattern key  : "<<str_initial_patternkey;
				cout<<"\n Initial Row data     : "<<str_row;
				cout<<"\n Initial column data  : "<<str_col;
				cout<<"\n Restored default data";								  
		   }
		   else
		   {
		   	   /* all initial values are valid, set the pattern attributes with the given initial values */
		       num_rows = initial_row ;
		       firstrow_col = initial_col;
	           pattern_format = tolower(str_initial_patternkey.at(0));
		       midrow = this->calc_term();
		       midrow_col = this->calc_term(firstrow_col, midrow,pattern_format );
		   }
		   if(DEBUG)
			  disp_pattern_input();
	   }  	    
/*--------------------------------------------------------------
FUNCTION NAME  : pattern_input()

PURPOSE        : Get data from user by keyboard, validate pattern attributes  

DESCRIPTION    : Get data from user by keyboard, validate pattern attributes and if all the given data are valid, 
                 sets pattern atribute, if any of them failed, then return non zero integer value.

INPUT          : none

OUTPUT         : sets pattern attributes with user data if valid and return 0 for SUCCESS, else
                 return with non zero integer data for failure operation.  

NOTE           : 

KNOWN BUGS     :
--------------------------------------------------------------*/	    
	int Pattern::pattern_input()
		{
			/* get pattern format key attrbute input from user by keyboard, validate */
			if(input_patternkey_data())
			     return 1;		       
			 /* get number of rows attribute for pattern input from user by keyboard, validate */	 	
			if(input_row_data())
			   return 1;
		    /* get number of columns in first row attribute for pattern input from user by keyboard, validate */	 			        	
	    	if(input_col_data())
	    	   return 1;
				/* all the pattern attribute data's feed by keyboard are valid */	
		    return 0;
		}

/*--------------------------------------------------------------
FUNCTION NAME  : disp_pattern_input()

PURPOSE        : displays a pattern attributes

DESCRIPTION    : if valid pattern format key is not set, sets pattern attributes with default and safe data,
                 and displays a pattern attributes.   

INPUT          : 

OUTPUT         : if attribute data are valid, return 0 for success operation, else return with non zero integer data for failure operation. 

NOTE           : 

KNOWN BUGS     :
--------------------------------------------------------------*/	
int Pattern::disp_pattern_input()
{
	char success = 'y';
	cout<<"\n Pattern Setting \n ==============================";
	/* if valid pattern format is not given, then set pattern attributes with default and safe data */
	if(disp_pattern_format_key())
	{
		/* set with default and safe data for pattern attributes */
	   default_pattern();	
	   success ='n';
    }
    /* display pattern attributes */
	cout<<"\n Number of rows in pattern                             : "<<num_rows;
    cout<<"\n Number of columns in the first row in pattern         : "<<firstrow_col;
    cout<<"\n Middle row in the pattern                             : "<<midrow;
    cout<<"\n Number of columns in the Middle row                   : "<<midrow_col; 
	if(success == 'y')
		return 0;
    return 1;
}	
/*--------------------------------------------------------------
FUNCTION NAME  : pattern_display()

PURPOSE        : displays a pattern with given pattern attribute datas  

DESCRIPTION    : for ascending or descending pattern format, display pattern progressively.
                 for ascending then descending or descending then ascending pattern format, display pattern symmetrically                   
 
INPUT          : 

OUTPUT         : displays pattern with given pattern attribute data and return 0 for success operation, 
                 else return with non zero integer data for failure operation.

NOTE           : used lesser middle row value if  number of rows for the pattern in the attribute is even.

KNOWN BUGS     :
--------------------------------------------------------------*/		
	 int Pattern::pattern_display()
	{
	    cout<<"\n \n Display Pattern";
	    cout<<"\n======================\n";
	    switch(pattern_format)
	    {
	    	/* ascending pattern format*/
	    	case 'a':
	    	/*  use num_rows and  firstrow_col data and increment number of columns for that row with fixed value with next successive rows till
			     maximum number of rows is met. eg for 2nd row, number of columns = 5, then if increment = 1 for each successive rows for 3nd row,
				 then number of columns = 5, and displays pattern format accordingly.*/	
	    	   this->asc_pattern(num_rows, firstrow_col) ;
               break;
            /* for descending pattern format */    
        	case 'd':
        	/*   use num_rows and  firstrow_col data and decrement number of columns for that row with fixed value with next successive rows till 
			     maximum number of rows is met. eg for 2nd row, number of columns = 5, then if decrement = 1 for sucessive rows, for 3nd row,
				 then number of columns = 4 and displays pattern format accordingly. */	
               this->desc_pattern(num_rows, firstrow_col);
			   break;
			/* ascending then descending pattern format, display pattern symmetrically */   
			case 'x':
			/*  for  use middle row  and corresponding number of column, and increment number of columns 
				for that row with fixed value with next successive rows till middle row, then according to number of rows, take action. */				
				   	
			   this->asc_pattern(midrow, firstrow_col) ;
			   /* if number of rows = even, eg maximum number of rows = 6, number of first row's columns = 5 , factor = 1, then middle row can be 3 or 4, 
			      we use 3 (lesser middle row) and for middle row (3), middle row's cols = 7, and increment for next successive row till middle row (3), 
				  then for greater middle row(4),  middle row's cols is same as lesser middle row , then for each successive row till max num of rows, decrement with same factor */
			   if(num_rows % 2 == 0)	
			      this->desc_pattern(num_rows - midrow, midrow_col );
			    else
			    /* if number of rows = odd, after middle row, decrement number of columns for that row with fixed value with next successive rows,
					till maximum number of rows is met. eg for maximum number of rows = 5, number of first row's columns = 5, factor = 1 then middle row = 3 and middle row's columns = 7,  
					for 2nd row, number of columns = 6, and increment for next successive row till middle row, then decrement with each same factor for each sucessive rows,
					for 3nd row, then number of columns = 5 and displays pattern format accordingly. */
				  this->desc_pattern(num_rows - midrow, midrow_col - 1 );	
			    break;
			/* for descending then ascending pattern format, display pattern symmetrically */       
			case 'z':
				/*  use middle row  and corresponding number of column, and decrement number of columns for that row with fixed value with next successive rows till
				    middle row, then according to number of rows, take action. */
				this->desc_pattern(midrow, firstrow_col) ;
				/* if number of rows = even, eg maximum number of rows = 6, number of first row's columns = 5, factor = 1, then middle row can be 3 or 4, 
				   we use 3 (lesser middle row) and for middle row (3), middle row's cols = 3, and decrement for next successive row till middle row (3),
				    then for greater middle row(4), middle row's cols is same as lesser middle row , then for each successive row till max num of rows, increment with same factor */
			    if(num_rows % 2 == 0)	
			      this->asc_pattern(num_rows - midrow, midrow_col );
			    else
			    /* if number of rows = odd, after middle row, increment number of columns for that row with fixed value with next successive rows,
					till maximum number of rows is met. eg for maximum number of rows = 5, number of first row's columns = 6, factor = 1, then middle row = 3 and middle row's columns = 4,  
					for 2nd row, number of columns = 5, and increment for next successive row till middle row, then increment with each same factor for each sucessive rows,
					for 3nd row, then number of columns = 5, then for each successive row till max num of rows, and displays pattern format accordingly. */
				  this->asc_pattern(num_rows - midrow, midrow_col + 1 );		
			   break;      
        	default:
        		 cout<<"\n ERROR[07]: Invalid pattern order key - "<<pattern_format;  
        		 default_pattern();
				 return 1; 			     	
		}
		return 0;
    }
/*--------------------------------------------------------------
FUNCTION NAME  : default_pattern()

PURPOSE        : sets default and safe pattern attributes datas

DESCRIPTION    : calculate middle row and middle row's number of column and 
                 sets default and safe pattern attributes datas  

INPUT          :  default and safe data to set  pattern attributes datas

OUTPUT         : 

NOTE           : used lesser middle row value if number of rows in pattern attribute's data is even.

KNOWN BUGS     :
--------------------------------------------------------------*/ 
int Pattern::default_pattern()
{
	/* set default and safe pattern attributes datas */
    num_rows =  DEFAULT_ROW;
	firstrow_col = 	DEFAULT_COL;
	pattern_format = default_pattern_key[0];
	/* middle row for lesser middle row value is used if max number of rows is even */
	midrow = this->calc_term();
	/*  number of column for middle row to display pattern */ 
	midrow_col = this->calc_term(firstrow_col, midrow,pattern_format );	
	return 0;
}
  
/*--------------------------------------------------------------
FUNCTION NAME  : calc_term()

PURPOSE        : calculate middle row 

DESCRIPTION    :

INPUT          : 

OUTPUT         :  middle row 

NOTE           : used lesser middle row value if number of rows for pattern in attribute's data is even.

KNOWN BUGS     :
--------------------------------------------------------------*/		
unsigned int  Pattern::calc_term()
 {
 	unsigned int middle_row;
 	/* is number of rows is odd or even, set middle row pattern attribute accordingly. 
	   lesser middle row value  are used if number of rows for the pattern is even */
 	middle_row = ( num_rows % 2 == 0) ? num_rows / 2: (num_rows / 2 ) + 1;
 	return middle_row;
 }
 /*--------------------------------------------------------------
FUNCTION NAME  : calc_term()

PURPOSE        : calculate nth term value with input as start value, number of terms and operation

DESCRIPTION    : use arithimetric progression, to calculate nth terms value 
                 FORMULA: T(n) = a + (n - 1) * d , where a = start value, n = nos of terms 
				 and d = T(n) - T(n - 1) . d =  common factor between next consective term value.				  

INPUT          :  initial value , number of terms and operation to determine either increment or decrement

OUTPUT         :  nth term value T(n) if valid, else return error value.

NOTE           : using function overloading and used mainly for column based calculation.
                 make sure that pattern is progressive for the given input datas

KNOWN BUGS     :
--------------------------------------------------------------*/
 int Pattern::calc_term(unsigned int initial_value, unsigned int terms, char oper)
{
	int term_value ;
    switch(oper)
	{
		/* first increment operation, then either decrement or not.
		  Make sure pattern is progressive for the given input datas */
	  	case 'a':
	  	case 'x':
		  /* use arithimetric progression */	
	   	  term_value = initial_value + ( (terms - 1) * (COMM_DIFF));
          break;
        /* first decrement operation, then either increment or not.
		  Make sure pattern is progressive for the given input datas */  
        case 'd':
        case 'z':
		 /* use arithimetric progression */	
          term_value = initial_value - ( (terms - 1) * (COMM_DIFF));
		  break;
		default:
	   	  cout<<"\n ERROR[01]: Invalid internal oper - "<<oper; 
	   	  /* set default and safe pattern attribute datas */
		  default_pattern(); 		 
		 /* to make sure that term value having more than -10000, chance is rare to have term value less than -10000.
		    -10000 is used to indicate error condition */ 
		 return -10000;   	
	}	
	return term_value;
}
/*--------------------------------------------------------------
FUNCTION NAME  : asc_pattern()

PURPOSE        : display pattern in ascending progressive order according to number of rows in the pattern and number of column of the first row in the pattern

DESCRIPTION    :

INPUT          : number of rows in the pattern and number of column of the first row in the pattern for progressive increment. 
                 ROW_NUMERIC - Initial display value for first column in each row and  ROW_NUMERIC_INCR = factor to display in pattern format for next column in a row in display pattern 

OUTPUT         : display pattern in ascending progressive order 

NOTE           : make sure that pattern is increment progressive for the given parameters.

KNOWN BUGS     :
--------------------------------------------------------------*/
 int Pattern::asc_pattern(unsigned int rows_num, unsigned int col_initial)
{
	int row_count = 0; /* current number of rows in pattern */
	int col_count = 0; /* current number of column in a row in the display */
	int cur_cell_val = 0;     /* current display value in a given cell */
	/* for each row in pattern to display */
    for(row_count = 0; row_count<rows_num ; ++row_count)
    { 
        /* for each column in a given row, increment progressive pattern display  */
	    for( col_count=0, cur_cell_val = (ROW_NUMERIC); col_count < row_count + col_initial ; ++col_count, cur_cell_val = cur_cell_val+ (ROW_NUMERIC_INCR ))
	       cout<<" "<<cur_cell_val;
	    cout<<endl; 
    } 	
	return 0;
}

/*--------------------------------------------------------------
FUNCTION NAME  : desc_pattern()

PURPOSE        : display pattern in descending progressive order, according to number of rows in the pattern and number of column of the first row in the pattern

DESCRIPTION    :

INPUT          : number of rows in the pattern and number of column of the first row in the pattern for progressive decrement. 
                 ROW_NUMERIC - Initial display value for first column in each row and  ROW_NUMERIC_INCR = factor to display in pattern format for next column in a row in display pattern 

OUTPUT         : displays pattern in descending progressive order

NOTE           : make sure that pattern is decrement progressive for the given parameters.

KNOWN BUGS     :
--------------------------------------------------------------*/
 int Pattern::desc_pattern(unsigned int rows_num, unsigned int col_initial)
{
	int row_count = 0; /* current number of rows in pattern */
	int col_count = 0; /* current number of column in a row in the display */
	int cur_cell_val = 0;  /* current display value in a given cell */
	/* for each row in pattern to display */
    for(row_count = 0; row_count<rows_num; ++row_count)
	{
		/* for each column in a given row, decrement progressive pattern display */
 	    for(col_count = col_initial - row_count, cur_cell_val = (ROW_NUMERIC);  col_count > 0; --col_count, cur_cell_val = cur_cell_val + (ROW_NUMERIC_INCR) )
 	       cout<<" "<<cur_cell_val;
        cout<<endl;
	}
	return 0;
}
/*--------------------------------------------------------------
FUNCTION NAME  : validate_row_data()

PURPOSE        : validate given data for number of rows in the pattern , if valid set the number of rows in the pattern attribute,
                 for invalid data, give appropiate information to guide user.  
                 
DESCRIPTION    : validate given data for number of rows in the pattern is a integer, within the range, if valid data, set the number of rows in the pattern attribute and 
                 calculate middle row, to be used for symmetric pattern display. If invalid data for number of rows in the pattern, give appropriate error message 
				 and give valid data range for number of rows in the pattern.                 

INPUT          : number of rows in the pattern to validate.

OUTPUT         : if validation is success, sets the number of rows in the pattern and returns 0, else return non zero integer. .  

NOTE           : used lesser middle row value if number of rows in the pattern in attribute's data is even.

KNOWN BUGS     :
--------------------------------------------------------------*/
 int Pattern::validate_row_data(string row_data)
{
	string compare_string;
	size_t sz;             
	long int i_dec;
	unsigned int temp;   
   /* is number of rows in the pattern to validate starts with numeric character */	
   if(row_data.at(0) >= '0' && row_data.at(0) <= '9')
   {	
        /* convert data for number of row for the pattern from string to integer */
        i_dec = stol (row_data, &sz, 10);
        /* convert integer to string */           
        compare_string  = to_string(i_dec);
        /* compare with converted string wth given data to check given data is an integer */
        if(compare_string.compare(row_data) == 0)
        {
        	/* given data for number of row for the pattern is integer  */
        	temp = (unsigned int)i_dec;
        	
   	      if( temp >= (MIN_ROW) && temp <= (MAX_ROW ) )
          {
          	/* number of row for the pattern is within range, set number of rows for the pattern in attribute */
         	  set_row_data(temp);
              return 0;
          }
          cout<<"\n ERROR[02]: Entered number of rows ["<<temp<<"] is out of range["<< (MIN_ROW )<<","<<( MAX_ROW)<< "]";
	    }
	    else 
	    {
	       cout<<"\n ERROR[04]: Begins with number but has non integer characters. Given row data : "<<row_data;		   
		}
   }
   else 
   {
      cout<<"\n ERROR[07]: Starting letter is not a number. Given row data : "<<row_data;	  
   }
   cout<<"\n INFO[09]: Valid row data's range [" <<(MIN_ROW) <<","<< (MAX_ROW)<< "]"; 
   return 1;	
}
/*--------------------------------------------------------------
FUNCTION NAME  : input_row_data()

PURPOSE        : get number of rows in the pattern from user by keyboard and validate it. prompt's to continue or not.
                 
DESCRIPTION    : 1: get number of rows in the pattern  from user by keyboard and validate it. 
                 2: If invalid data for number of first rows in the pattern , prompt user to continue to enter data or exit application,
				 3: If user presses 'y' or 'Y', enter data and validate the number of rows in the pattern, any other key(s), return non zero integer
				 to exit application.
				 4: if valid data for number of columns in the first row in the pattern, then set row attribute. and return 0, for successful operation                                

INPUT          : number of rows for the pattern from user by keyboard in string and user input to iternate if invalid data for number of rows in the pattern 

OUTPUT         : if valid data, sets the row attribute and returns 0, for invalid data return non zero integer. 

NOTE           : 

KNOWN BUGS     :
--------------------------------------------------------------*/
int Pattern::input_row_data()
{
	   string input_str, to_iterate;	  
	   do
	   {  	
			cout<<"\n Enter number of rows in the pattern  : ";
			/* get for number of rows in the pattern attribute from keyboard */
			cin>>input_str; 
			/* if valid data for number of rows in the pattern attribute, then return 0 for successful operation */	
			if(!validate_row_data(input_str))
			   return 0;  
			/* invalid data for number of rows in the pattern attribute, prompt to continue feed data for number of rows in the pattern attribute.
			  if user press key 'y' or 'Y', continue to enter number of rows in the pattern attribute, any other key(s) return non zero integer
			  to exit application */          	   
	       cout<<"\n Do want to again enter number of rows in the pattern ? ";
		   cout<<"\n Press key 'y' or 'Y' to continue, any other key(s) to exit application: Enter key -  ";
		   cin>>to_iterate;		    	   
       }
       while(to_iterate.length() == 1 && (to_iterate.at(0) == 'y' || to_iterate.at(0) == 'Y')); 
	    /* for user has requested to exit application, return non zero integer. */       	
	return 1;
}
/*--------------------------------------------------------------
FUNCTION NAME  : set_row_data()

PURPOSE        : set data for row attributes .

DESCRIPTION    : number of rows in the pattern with given input and calculate middle row to be used for symmetric pattern display 

INPUT          : valid data for number of rows in the pattern to set row attributes. 

OUTPUT         : sets data for row attributes .

NOTE           : used lesser middle row value if number of rows in the pattern in attribute's data is even.

KNOWN BUGS     :
--------------------------------------------------------------*/
int Pattern::set_row_data(unsigned int valid_row_data)
{
	num_rows = valid_row_data;
	if(DEBUG)
        cout <<"\n INFO[02]: Entered number of rows for the pattern : "<<num_rows; 
    /* calculate middle row to be used for symmetric pattern display */   
    midrow = calc_term();
    return 0;
	
}
/*--------------------------------------------------------------
FUNCTION NAME  : input_col_data()

PURPOSE        : get number of columns in the first row in the pattern from user by keyboard and validate it. prompt's to continue or not.
                 
DESCRIPTION    : 1: get number of columns in the first row in the pattern  from user by keyboard and validate it. 
                 2: If invalid data for number of columns in the first row in the pattern , prompt user to continue to enter data, or exit application
				 3: If user presses 'y' or 'Y', enter data and validate the number of columns in the first row in the pattern, any other key(s) 
				    return non zero integer to exit application
				 4: if valid data for number of columns in the first row in the pattern, then set column attribute and return 0 for successful operation,                    

INPUT          : 

OUTPUT         : if valid data, sets the number of columns in the first row in the pattern and returns 0. For user has requested to exit application, return non zero integer. 

NOTE           : 

KNOWN BUGS     :
--------------------------------------------------------------*/
 int Pattern::input_col_data()
{ 
  string input_str, to_iterate;
  
  do
  { 
      cout<<"\n Enter number of columns in the first row in pattern : ";
      	/* get number of columns in the first row in the pattern attribute from keyboard */
	  cin>>input_str;
	  /* if valid data for number of columns in the first row in the pattern, then return 0 for successful operation */	
	  if(!validate_col_data(input_str))
		 return 0; 
	 /* invalid data for  number of columns in the first row,  prompt to continue feed data for number of columns in the first row in the pattern .
		if user press key 'y' or 'Y', then continue to enter number of columns in the first row in the pattern, any other key(s) return non zero integer
		 to exit application */ 	 
	 cout<<"\n Do want to enter number of columns in the first row in pattern ? ";
	 cout<<"\n Press key 'y' or 'Y' to continue, any other key(s) to exit application: Enter key -  ";
	 cin>>to_iterate;		    	   
  }
  while(to_iterate.length() == 1 && (to_iterate.at(0) == 'y' || to_iterate.at(0) == 'Y')); 
  /*  for user has requested to exit application, return non zero integer. */
   return 1;			    
}

/*--------------------------------------------------------------
FUNCTION NAME  : validate_col_data()

PURPOSE        : validate given data for number of columns in the first row in the pattern, if valid set the number of columns 
                 in the first row in the pattern attribute, for invalid data, give appropiate information to guide user. 
                 
DESCRIPTION    : validate given data for number of columns in the first row  is a integer, within the range, if valid data, set the the number of columns in the first row
                 in the pattern attribute and calculate number of column for the middle row, to be used for symmetric pattern display.
				 If invalid data for number of columns in the first row in the pattern, give appropriate error message 
				 and give valid data range for number of columns in the first row for the given pattern format and number of rows in the pattern.                

INPUT          : number of columns in the first row to validate. 

OUTPUT         : if validation is success, sets the number of columns in the first row  and returns 0, for invalid data return non zero integer. 

NOTE           : 

KNOWN BUGS     :
--------------------------------------------------------------*/
int Pattern::validate_col_data(string col_data)
{
    string compare_string;
	size_t sz;             
	long int i_dec;
	unsigned int  temp;
	int term_value, min_max_range ;  
	/* is the given number of columns in the first row in the pattern to validate starts with numeric character */	
    if(col_data.at(0) >= '0' && col_data.at(0) <= '9')
	{	 
	     /* convert data for number of columns in the first row in the pattern from string to integer */		
         i_dec = stol (col_data, &sz, 10);
		 /* convert integer to string */                
         compare_string = to_string(i_dec);
          /* compare with converted string wth given data to check given data is an integer */
         if(compare_string.compare(col_data) == 0)
         {
         	/* given data for number of columns in the first row in the pattern is integer */
           	 temp = (unsigned int ) i_dec ;
           	 /* according to pattern format, valid range for data for number of columns in the first row in the pattern changes */
          	 switch(pattern_format) 
	         {
	         	/* for ascending pattern format */
		    	case 'a':
		    		/* calculate number of columns for the last row in the pattern  */
		    		term_value = calc_term( temp, num_rows, pattern_format );
		    		/* is given data within range for number of columns in the first row in the pattern 
					   or number of columns for the last row in the pattern exceeds maximum limit for column in pattern */
		    		if( term_value > (MAX_COL) || !(temp >= (MIN_COL) &&  temp <= (MAX_COL )))
                    {
                       cout<<"\n ERROR[05]: Entered column data ["<<temp<<"] may be out of range ["<< (MIN_COL) <<","<<( MAX_COL)<< "]";
					   cout<<"\n OR for ASC pattern, column last term's value ["<<term_value<<") may be > MAX_COL ["<<(MAX_COL)<<"]";					  
                    }  
					else 
					{
						/* given data within range for number of columns in the first row in the pattern is within valid range,
						  set  number of columns in the first row in the pattern with the given data and calculate number of columns for the middle row, 
						  to be used for symmetric pattern display */
					    set_col_data(temp);
						return 0;
					}         	                   
                   	break;
                   	/* for descending pattern format*/
				case 'd':
					/* calculate number of columns for the last row in the pattern  */
		        	term_value = calc_term( temp, num_rows, pattern_format );
		        	/* is given data within range for number of columns in the first row in the pattern 
					   or number of columns for the last row in the pattern is less than miniumum limit for column data in pattern */ 
		            if(num_rows > temp  || term_value < (MIN_COL) || !( temp >= (MIN_COL) && temp <= (MAX_COL)))
		            {
		                cout<<"ERROR[12]: Entered column data ["<<temp<<"] may be out of range ["<< (MIN_COL) <<","<<( MAX_COL)<< "])" ;
					    cout<<"\n OR for DESC pattern, column last term's value ["<<term_value<<"] may be < MIN_COL ["<<(MIN_COL)<<"]";
					    
				    }
			       else 
			       {
			             /* given data within range for number of columns in the first row in the pattern is within valid range,
						  set  number of columns in the first row in the pattern with the given data and calculate number of columns for the middle row, 
						  to be used for symmetric pattern display */
					    set_col_data(temp);
						return 0;			
				    }
				    break;	
				/* for ascending then descending pattern format*/											  					   
                case 'x': 
                    /* number of columns in the middle row, for the given data has maximum number of columns in the pattern, calculate it, and check if it exceeds maximum limit of column
					  or  given number of columns in the first row is within range of column data */
                    term_value = calc_term( temp, midrow, pattern_format );
                    if( term_value > (MAX_COL ) ||!(temp >= ( MIN_COL) && temp <= (MAX_COL ) ))
           	        {
           	           	cout<<"\n ERROR[21]: Entered column data ["<<temp<<"] may be out of range ["<<( MIN_COL) <<","<<( MAX_COL)<< "]";
           	            cout<<"\n OR for ASC-DES pattern, col max term's value ["<<term_value<<"] may be > MAX_COL ["<<(MAX_COL)<<"]";
           	           
           	        } 
					else
					{			
					    /* given data within range for number of columns in the first row in the pattern is within valid range,
						  set  number of columns in the first row in the pattern with the given data and calculate number of columns for the middle row, 
						  to be used for symmetric pattern display */
					    set_col_data(temp);
						return 0;	
				    }
                    break; 
				/* for descending then ascending  pattern format */		                         	 
                case 'z': 
				    /* number of columns in the middle row, for the given data has minimum number of columns in the pattern, calculate it, and check if it less then minimum limit of column
					  or is given number of columns in the first row  within range of column data  */
					                        	 
                    term_value = calc_term( temp, midrow ,pattern_format );
				    if(midrow > temp || term_value <(MIN_COL) || !( temp >= (MIN_COL ) && temp <= ( MAX_COL)  ))
				    {
				    	cout<<"\n ERROR[21]: Entered column data ["<<temp<<"] may be out of range ["<<( MIN_COL) <<","<<( MAX_COL)<< "]";
           	            cout<<"\n OR for DES-ASC pattern, col max term's value ["<<term_value<<"] may be > MAX_COL ["<<(MAX_COL)<<"]";           	            
				    }
				    else 
           	        {
				         /* given data within range for number of columns in the first row in the pattern is within valid range,
						  set  number of columns in the first row in the pattern with the given data and calculate number of columns for the middle row, 
						  to be used for symmetric pattern display */
					    set_col_data(temp);
						return 0;			
				    }
				    break;
				    /* invalid pattern format, set default and safe data for pattern attributes */
					default:
					   cout<<"\n ERROR[13]: Invalid pattern format - "<<pattern_format;	
					   default_pattern();					      
			}			
        }                      
        else 
        {
		   cout<<"\n ERROR[06]: Begins with number but has non numeric characters. Given col data : "<<col_data;		   
	    }
	 }
	 else
	 {
	 	cout<<"\n ERROR[08]: Starting letter is not a number. Given col data : "<<col_data;	 		 	
	 }
	 /* given informaton for the valid range number of columns in the first row, as valid range varies based on pattern format and given number of rows in the pattern.
	    switch based on pattern format is used again, as previous switch requires validate integer data for column.
		to avoid repeatation for valid range informaton for invalid numeric data for number of columns in the first row in the pattern */
	 switch(pattern_format)
	 {
	 	case 'a':
	 		/* for ascending pattern format maximum limit that data for number of columns in the first row changes can have for a particular number of rows in the column  */
	 		/* use arthimetic progressive */
		   min_max_range = (MAX_COL) - (num_rows - 1) *(COMM_DIFF);	
		   cout<<"\n \n INFO[06]: Valid col data's' range ["<<(MIN_COL)<<","<<min_max_range<<"] for row data ["<<num_rows<<"] for ASC pattern";
		   break;
		case 'd':
			/* for descending pattern format minumum limit that data for number of columns in the first row changes can have for a particular number of rows in the column  */
	 		/* use arthimetic progressive */
		    min_max_range	 = (MIN_COL) + (num_rows - 1)*(COMM_DIFF);
		    cout<<"\n \n INFO[07]: Valid col data's range ["<<min_max_range<<","<<(MAX_COL)<< "] for row data ["<<num_rows<<"] for DESC pattern";  
		    break;
		case 'x':
		    min_max_range = (MAX_COL) - (midrow - 1) *(COMM_DIFF) ;
		    cout<<"\n \n INFO[08]: Valid col data's range ["<<(MIN_COL)<<","<<min_max_range<<"] for row data ["<<num_rows<<"] for ASC then DESC pattern";
			break;
		case 'z':
		   min_max_range	 = (MIN_COL) + (midrow - 1)*(COMM_DIFF);
		   cout<<"\n \n INFO[09]: Valid col data's range ["<<min_max_range<<","<<(MAX_COL)<< "] for row data ["<<num_rows<<"] for DESC then ASC pattern"; 		  
		default:
		   cout<<"\n ERROR[22]: Invalid pattern format - "<<pattern_format;
		   default_pattern();	       
	 }
	 return 1;      
}
/*--------------------------------------------------------------
FUNCTION NAME  : set_col_data()

PURPOSE        : set data for column attributes .

DESCRIPTION    : number of columns in the first row in the pattern with given input and 
                calculate number of columns for the middle row, to be used for symmetric pattern display 

INPUT          : valid data for  number of columns in the first row in the pattern to set column attributes. 

OUTPUT         : sets data for column attributes .

NOTE           : used lesser middle row value if number of rows in the pattern in attribute's data is even.

KNOWN BUGS     :
--------------------------------------------------------------*/
int Pattern::set_col_data(unsigned int valid_col_data)
{
	firstrow_col = valid_col_data;
	if(DEBUG)
       cout <<"\n INFO[01]: Entered  number of columns in the first row in pattern : "<<firstrow_col;
	 midrow_col = calc_term(firstrow_col, midrow, pattern_format );
    return 0;	
}
/*--------------------------------------------------------------
FUNCTION NAME  : validate_patternkey_data()

PURPOSE        : validate given data for pattern format , if valid set the sets pattern format key, for invalid data, give appropiate information to guide user. 

DESCRIPTION    : if the given pattern key data is either 'a' or 'A' for ascending pattern format, 'd' or 'D' for descending pattern format,
                 'x' or 'X' for ascending then descending pattern format, 'z' or 'Z' for descending then ascending pattern format. then valid pattern format, for invalid
                  

INPUT          : to validate pattern format key

OUTPUT         :  if validation is success, sets the pattern format key and returns 0, for invalid data return non zero integer.  

NOTE           : 

KNOWN BUGS     :
--------------------------------------------------------------*/
 int Pattern::validate_patternkey_data(string pattern_key_data)
{
   if(pattern_key_data.length() == 1 && ( pattern_key_data.at(0) =='a' || pattern_key_data.at(0)=='A' || pattern_key_data.at(0) =='d' || pattern_key_data.at(0)=='D' \
		      || pattern_key_data.at(0) =='x' || pattern_key_data.at(0)=='X' || pattern_key_data.at(0) =='z' || pattern_key_data.at(0)=='Z'  ))
	{
		 /* valid pattern format key.set pattern format key to the lowercase for the correspondng pattern format key */
	      pattern_format =tolower(pattern_key_data.at(0)); 
	      return 0;	        
	}
	else
		cout<<"\n ERROR[20]: Invalid pattern format key - "<<pattern_key_data;
	return 1;
}
/*--------------------------------------------------------------
FUNCTION NAME  : input_patternkey_data()

PURPOSE        : 1: get pattern format key from user by keyboard and validate it. 
                 2: If invalid data for  pattern format key , prompt user to continue to enter data, or exit application
				 3: If user presses 'y' or 'Y', enter data and validate the pattern format key, any other key(s) 
				    return non zero integer to exit application
				 4: if valid data for pattern format key, then set pattern format key and return 0 for successful operation, 

DESCRIPTION    :

INPUT          : use key 'a' or 'A' for ascending pattern format, use key 'd' or 'D' for descending pattern format,
                 use key 'x' or 'X' for ascending then descending pattern format, use key 'z' or 'Z' for descending then ascending pattern format.

OUTPUT         : if valid data, sets the  pattern format key and returns 0. For user has requested to exit application, return non zero integer.  

NOTE           : 

KNOWN BUGS     :
--------------------------------------------------------------*/
 int Pattern::input_patternkey_data()
{
     string pattern_format;
     string to_iterate;
	
	 do
	 {
	    cout<<"\n For pattern format : "<< "\n======================= ";
		cout<<"\n Press key 'a' or 'A' for ascending OR"<<"\n key 'd' or 'D' for descending OR";
        cout<<"\n key 'x' or 'X' for ascending to descending OR"<< "\n key 'z' or 'Z' descending to ascending";
		cout<<"\n Enter pattern format key -  ";
		/* get pattern format key data from keyboard */
		cin>>pattern_format;	
		/* if valid data for pattern format key, then return 0 for successful operation */	
		if(!validate_patternkey_data(pattern_format))
		    return 0;
		 /* invalid data for pattern format key,  prompt to continue feed data for  pattern format key. If user press key 'y' or 'Y', then
		   continue to enter pattern format key, any other key(s) return non zero integer  to exit application */    
		cout<<"\n Do you want to correct pattern format key ? "	;
		cout<<"\n Press key 'y' or 'Y' to continue, other key(s) to exit application : Enter - ";
		cin>>to_iterate;  	 	
	 } while(to_iterate.length() == 1 && ( to_iterate.at(0) =='y' || to_iterate.at(0) =='Y'));
     /*  for user has requested to exit application, return non zero integer. */
   return 1;
}
/*--------------------------------------------------------------
FUNCTION NAME  : disp_pattern_format_key()

PURPOSE        : displays a pattern order format in words with given pattern format key 

DESCRIPTION    :

INPUT          : 

OUTPUT         : displays pattern format in words. 

NOTE           : 

KNOWN BUGS     :
--------------------------------------------------------------*/
 int Pattern::disp_pattern_format_key( )
{
    switch (pattern_format)
    {
    	case 'a':
   	      	cout<<"\n Pattern format                    : Ascending";
   	    	break;
   	    case 'd':
            cout<<"\n Pattern format                    : Descending";
	        break;
	    case 'x':
            cout<<"\n Pattern format                    : Ascending then Descending";
	        break;
	    case 'z':
	       cout<<"\n Pattern format                     : Descending then Ascending";
	       break;
	   default:
	       cout<<"\n ERROR[11]: Invalid pattern format key "<<pattern_format;	
	   return 1;					 	
    } 
    return 0;
}

/*--------------------------------------------------------------
FUNCTION NAME  : main()

PURPOSE        : ask for user input to iterate to get input parameter and display pattern according to 
                 set parameters. If user press key 'y' or 'Y', continue or any other key(s) to exit application. 
				 
DESCRIPTION    : 1: prompt to continue, if user presses key 'y' or 'Y', continue go to step 2 or any other key(s) to exit application. 
                 2:	user has requested to get pattern format key data from keyboard, if valid pattern format key, go to step 3, for invalid pattern format key data,
				   prompt to continue, if user presses key 'y' or 'Y', continue go to step 2 or any other key(s) to exit application.
				 3: for valid pattern format key data, get number of rows in the pattern data from keyboard, if valid row data, go to step 4, for invalid row data,
				   prompt to continue, if user presses key 'y' or 'Y', continue go to step 2 or any other key(s) to exit application.
				 4: for valid number of rows in the pattern data, get number of columns in the first row in the pattern data from keyboard, if valid column data, go to step 5,
				    for invalid column data, prompt to continue, if user presses key 'y' or 'Y', continue go to step 2 or any other key(s) to exit application.	
				 5: all pattern attribute data are valid (ie) pattern format key data , number of rows in the pattern data and number of columns in the first row in the pattern data.
				    displays pattern according to  pattern attribute datas.
				 6: goto step 1.	 			  

INPUT          : user input to continue to iterate, if key 'y' or 'Y' get attributes from keyboard, validate input attributes and
                 display pattern depending on attribute datas. pattern attributes - number of rows in the pattern, number of columns in the first row and patter format key  

OUTPUT         : displays pattern according to valid pattern attributes  - number of rows in the pattern, number of columns in the first row and patter format key

NOTE           : 

KNOWN BUGS     :
--------------------------------------------------------------*/
int main()
{
	string to_continue ;
    int iteration_continue = 0;
    char is_iterate = 'y';
    /* create object with initial datas for pattern attributes*/
    Pattern disp_pattern(initial_pattern, INITIAL_ROW , INITIAL_COL );
	do
	{
		cout<<"\n Do you want to enter parameters and display pattern";
		cout<<"\n Press key 'y' or 'Y' to continue, any other key(s) to exit application. Enter - ";
	      	cin>>to_continue;
	    /* prompt to continue feed data for number of columns in the first row in the pattern . If user press key 'y' or 'Y', 
		  then continue to get pattern datas, any other key(s) exit the application */		 	
	   	if(to_continue.length() == 1 && (to_continue.at(0) == 'y' || to_continue.at(0) == 'Y') )
	   	{	  
		   /* user prompts to get and validate pattern attribute datas */ 
	    	if(!disp_pattern.pattern_input() )
	    	 {	
	    	     /* all the pattern attribute datas are valid */
			     disp_pattern.disp_pattern_input(); 
				 /* display pattern according to pattern attribute datas */	   
	    	     disp_pattern.pattern_display();
	    	     ++iteration_continue;	    	
			}
			else
			{
				/* user has requested to exit application mid way through any feed invalid attribute data */
			   is_iterate ='n';  			   
		    }
    	}
    	else
    	   is_iterate ='n';
		cout<<"\n ==============================================================";     
	} while(is_iterate =='y');
	/* user has requested to exit application */
	cout<<"\n Total iteration's on pattern display - "<<iteration_continue<<" and Exited. Have a nice day";
	cout<<"\n ==============================================================";
	return 0;
}

/*-----------------------------------------------------------------------------------------------
------------------------- -----------------------  END OF FILE -------------------------- -------
-------------------------------------------------------------------------------------------------*/                 
