/* ********************************************************************
FILE                   : ref.cpp

PROGRAM DESCRIPTION    : pass data by reference

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <iostream>
#include <string>
using namespace std;
void first_pass_ref(string& data_str);
void second_pass_ref(string& data_str);

int main()
{

	long  valid_data;
	string data_str = "12";
	size_t sz; 
	first_pass_ref(data_str);
	valid_data = stol(data_str,&sz );
	cout<<"\n valid_data = "<<valid_data<<" & data_str = "<<data_str;
	return 1;
}
void first_pass_ref(string& data_str)
{
	second_pass_ref(data_str);
	return;
}

void second_pass_ref(string& data_str)
{
	data_str = "20";
	return;
}
