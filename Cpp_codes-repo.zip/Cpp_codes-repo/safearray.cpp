/* ********************************************************************
FILE                   : safearray.cpp

PROGRAM DESCRIPTION    : safe array 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include <iostream>

using namespace std;
class Safe_array
{
	private:
		enum { LIMIT = 30 };
		int arr[LIMIT];
		size_t lower_index;
		size_t upper_index;
	public:
		int putel(size_t, int);
		int getel(size_t) const;
		void lower_limit();
		int upper_limit();
		int& operator [] (size_t);
		
};
void Safe_array::lower_limit()
{
	size_t lower;
	cout<<"\n Enter lower limit of array = ";
	cin>>lower_index;	
}
int Safe_array::upper_limit()
{
	size_t upper;
	cout<<"\n upper limit of array ["<<lower_index<<","<<lower_index + LIMIT<<"]. Enter upper limit = ";
    cin>>upper;
    if(lower_index > upper ||upper > lower_index + LIMIT )
    {
    	cout<<"\n ERROR[03]: lower index["<<lower_index<<"] > upper["<<upper<<"] OR upper exceeds max limit["<<lower_index + LIMIT<<"]";
    	return 1;
	}
	upper_index = upper ;
	return 0;
}
 int Safe_array::putel(size_t index, int temp)
{
	if(index>= lower_index && index<= upper_index)
	{
		arr[index - lower_index] = temp;
		return 0;
    }   
	cout<<"\n ERROR[01] : index out of bounds("<<index<<") with valid range ["<<lower_index<<","<<upper_index<<"]";
	return -1;
}
int Safe_array::getel(size_t index) const
{
	int temp;
	if(index>= lower_index && index<= upper_index)
	{
	     temp = arr[index - lower_index] ;
		return temp;
    }   
	cout<<"\n ERROR[02] : index out of bounds("<<index<<") with valid range ["<<lower_index<<","<<upper_index<<"]";
	return -1;
} 
int& Safe_array::operator [] (size_t index)
{
	int temp = -1;
	if(index>= lower_index && index<= upper_index)
	{
		return arr[index - lower_index];
	}
	cout<<"\n ERROR[03] : index out of bounds("<<index<<") with valid range ["<<lower_index<<","<<upper_index<<"]";
	exit(1); 
}
int main()
{
	Safe_array array;
	string to_iterate = "y";
	size_t index;
	int temp;
	do
	{
	    array.lower_limit();
	    if(array.upper_limit())
	    {
	       continue;
	    }
	    cout<<"\n Enter index = ";
	    cin>>index;
	    /* commented to access arr by overloaded function only */
    	/* if(array.putel(index, 500))
    	{
    		continue;
		}
        temp = array.getel(index); */
        array[index] = 1000;
        temp =  array[index]; 
	    cout<<"\n ANS[01]: index = "<<index<<", value = "<<temp;
    	cout<<"\n Do you want to continue ";
    	cout<<"\n Press 'y' or 'Y' to continue, any other to exit. Enter key = ";
    	cin>>to_iterate;
	} while (to_iterate.length() == 1 &&(to_iterate.at(0) =='y' || to_iterate.at(0) =='Y' ));
	return 1;
}

