/* ********************************************************************
FILE                   : price_03.cpp

PROGRAM DESCRIPTION    : calc total estimate of cost for painting rooms 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <iostream>

using namespace std;

int main()
{
	unsigned int  number_of_small_rooms {0}, number_of_large_rooms {0};
	cout <<"Welcome to Cleaning service "<<endl;
	cout <<"\n Enter number of small rooms: ";
	cin>> number_of_small_rooms;
	cout <<"\n Enter number of large rooms: ";
	cin>> number_of_large_rooms;
	const double price_per_small_rooms {25}, price_per_large_rooms {35}, sales_tax {0.06};
	const unsigned int expiry_days {30};
	cout<<endl<<"Number of small rooms : "<<number_of_small_rooms<<endl;
	cout<<"Number of large rooms : "<<number_of_large_rooms<<endl;
    cout<<"Price per small room : "<<price_per_small_rooms<<endl;
	cout<<"Price per large room : "<<price_per_large_rooms<<endl;
	cout<<"cost: "<< number_of_small_rooms * price_per_small_rooms +   number_of_large_rooms * price_per_large_rooms<<endl;
	cout<<"tax : "<< (number_of_small_rooms * price_per_small_rooms +   number_of_large_rooms * price_per_large_rooms) *sales_tax<<endl;
	cout << "total estimate : "<<(number_of_small_rooms * price_per_small_rooms +   number_of_large_rooms * price_per_large_rooms) +
	   ((number_of_small_rooms * price_per_small_rooms +   number_of_large_rooms * price_per_large_rooms) *sales_tax) <<endl;
	      

	return 0;
}
