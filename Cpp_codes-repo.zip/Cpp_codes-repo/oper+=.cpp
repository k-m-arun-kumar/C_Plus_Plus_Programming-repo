/* ********************************************************************
FILE                   : oper+=.cpp

PROGRAM DESCRIPTION    : operator +=

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <iostream>
#include <cstring>
using namespace std;

class String
{
	private:
		enum { MAX = 30	};
		char str[MAX];
	public:
	   String()
	   {
	   	  str[0] = '\0';
	   }
	   String(char s[])
	   { 
	      strcpy(str, s);
		  cout<<"\n INFO[01]: In constructor of 1 arg: str = "<<str;
	   }
	   void getstr()
	   {
	   	  cout<<"\n Enter string : ";
	   	  cin.get(str, MAX);
	   }
	   void display() const
	   {
	   	  cout<<"\n str = "<<str;
	   	  return;
	   }
	   	String operator += (String ss) 
	   	{
	   		if( strlen(str) + strlen(ss.str) < MAX )
            {
               strcat(str, ss.str); //add the argument string
            }
             else
             { 
			      cout << "\nString overflow";
				   exit(1); 
			  }
              return String(str); //return temp String
		}
};

int main()
{
    String s1, s3;
    String s2 = " Hello world";
    
    s1.getstr();
    s3  = s1+=s2;
    s3.display();
    s1.display();
 	return 1;
}
