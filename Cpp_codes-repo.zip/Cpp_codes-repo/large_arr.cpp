/* ********************************************************************
FILE                   : large_arr.cpp

PROGRAM DESCRIPTION    : practise array in C++

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include <iostream>
#include <string>
using namespace std;
#define MAX 20
size_t large(int[], size_t );
int main()
{
	int arr[MAX], temp;
	size_t index = 0;
	do
	{
		cout<<"\n Enter a number for a array : 0 to exit = ";
		cin>>temp;
		arr[index++] = temp;		
	}while (temp != 0);
	size_t large_index =large(arr, index - 1) ;
	cout<<"\n largest element : "<<arr[large_index]<<" , index : "<<large_index; 
	return 1;
}
size_t large(int arr[], size_t num_element )
{
   size_t index = 0, cur_large=0;
   while(index<= num_element ) 
   {
   	   if(arr[index] > arr[cur_large])
   	      cur_large = index;
   	   ++index;   
   }
   return cur_large;
}

