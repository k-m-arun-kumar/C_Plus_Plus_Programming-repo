/* ********************************************************************
FILE                   : cout.cpp

PROGRAM DESCRIPTION    : practise cout function

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <iostream>
using namespace std;
int main()
{
	int favourite_int;
	double favourite_double;
	
	std::cout << "Enter int : "; 
	std::cin >> favourite_int;
	std::cout <<" Enter double : ";
	std::cin >> favourite_double;
	std::cout << "That's my favourite int too!"<< std::endl;
	std::cout << "Not really!! " << favourite_int << " is favourite int & " << favourite_double<<" is favourite double"<<std:: endl;
	return 0;
}
