/* ********************************************************************
FILE                   : constr.cpp

PROGRAM DESCRIPTION    : practise constant

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <iostream>
using namespace std;

class c
{
	private:
		const int int_val;
		float fl_val;
	public:
	   c(int const_val, float ft ) : int_val(const_val),fl_val(ft)
	   {
	   	cout<<"\n In constructor int_val : "<<int_val<<" & fl_val : "<<fl_val;
	   }
	   /* constuctor cannot initialize const member or reference data in the constructor's function body */
	  /* c() 
	   {
	   	int_val = 1 ;
		fl_val  = 1.0;
	   } */
  int set_data(float ft);
  int disp_data()
  {
  	cout<<"\n int_val : "<<int_val<<" & fl_val : "<<fl_val;
  	return 0;
  }
	   	
};

inline int c::set_data(float ft)
{
  	  fl_val = ft;
   	  return 0;
}

int main()
{
	c c_obj(2,2.0);
		
	c_obj.set_data(4.0);
	c_obj.disp_data();
	
/*	c c_obj1();
	c_obj1.set_data(4.0);
	c_obj1.disp_data(); */
	return 0;
}
