/* ********************************************************************
FILE                   : const_06.cpp

PROGRAM DESCRIPTION    : practise constant

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <iostream>
#include <string>

using namespace std;

class Account
{
	private:
	  string name {"XXXXX"};
	  double balance;
    public:
	  Account();
	 ~Account()
    {
       cout <<name<<" Destuctor called"<<endl;	
    }         
};
Account::Account() : balance{1000}
{
  	    cout <<"In no arg constructor "<<name<<" has balance = " <<balance <<endl; 
} 
int main()
{
	Account arun;
	
	return 0;	
}
