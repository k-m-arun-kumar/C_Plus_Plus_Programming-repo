/* ********************************************************************
FILE                   : money_conv.cpp

PROGRAM DESCRIPTION    : calc money conversion

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include <iostream>
#include <cmath>
#include <string>

#define RUPEE_PER_DOLLAR   50
#define DOLLAR_KEY   'd'
#define RUPEE_KEY    'r'
#define OTHER_KEY    'o' 

#define ERROR_NO_TRAIL_DATA   -1
#define ERROR_NO_LEAD_DATA    -2

#define DEBUG 01 
using namespace std;

class Dollar
{
	   double money_dollar;	   
	public:
		Dollar() : money_dollar(0.0)
		{
		}
		Dollar( double money) : money_dollar(money)
		{
			
		}
		void set_dollar(double money) 
		{
			money_dollar = money;
			return;
		}
		double get_dollar() const
		{
			return money_dollar;
		}
		void disp_dollar() const
		{
			cout<<" Dollar = $"<<money_dollar;
			return;
		}
		Dollar operator + (Dollar dollar_obj) const
		{
			double dollar_add = money_dollar + dollar_obj.money_dollar;
			cout<<"\n $"<<dollar_add<<" = $"<<money_dollar<<" + $"<<dollar_obj.money_dollar;
			return Dollar(dollar_add);
		}
		 
};
class Rupee
{
	double money_rupee;
	public:
		Rupee() : money_rupee(0.0)
		{
		}
		
		Rupee( double money) : money_rupee(money)
		{
			
		}
		/* dollar to rupee conversion */
		explicit Rupee(Dollar dollar_obj )
		{
	    	money_rupee = dollar_obj.get_dollar() *	RUPEE_PER_DOLLAR;
		}
		void set_rupee(double money) 
		{
			money_rupee = money;
			return;
		}
		void disp_rupee() const
		{
			cout<<" Rupee = Rs"<<money_rupee;
			return;
		}
		/*  rupee to dollar conversion */
		operator Dollar() const
		{
			double rupee_to_dollar =  money_rupee / RUPEE_PER_DOLLAR;
			return Dollar(rupee_to_dollar);
		}
};
double getmoney(string, char&);
int white_space_remove(const string& input_string, string& nospace_data_str);
int main()
{
    Dollar dollar_obj[2] = {1000.0, 1000.0};
	Rupee rupee_obj;
	
	string to_iterate = "y", money_str;
	double money;
	char money_key = OTHER_KEY;
	do
	{
		cin.sync(); // all unread datas feed from keyboard are flushed.
    	cout<<"\n Enter money in dollar[$]/rupee[Rs] = ";
		getline(cin,money_str,'\n' );
		money = getmoney(money_str,money_key );	
		cin.sync();
		if(money < 0.0 )
		   continue;
		switch(money_key)
		{
		   case DOLLAR_KEY:
		      dollar_obj[0].set_dollar(money);
		      dollar_obj[0].disp_dollar();	
			  rupee_obj = static_cast<Rupee>(dollar_obj[0]);
			  cout<<" is converted to";
			  rupee_obj.disp_rupee(); 
			  
		      break;
		   case  RUPEE_KEY:
		      rupee_obj.set_rupee(money);
		      rupee_obj.disp_rupee();
			  dollar_obj[1] = static_cast<Dollar>(rupee_obj);
			  cout<<" is converted to";
			  dollar_obj[1].disp_dollar();	
			  cout<<"\n =======================";
			  dollar_obj[1] = dollar_obj[0] + rupee_obj;
			  
		      break;
		  default:
		      cout<<"\n ERROR[01]: Invalid money key = "<<money_key;  
		} 
		cout<<"\n Do you want to continue ? ";
    	cout<<"\n Press 'y' or 'Y' to continue, any other to exit. Enter key = ";
    	cin>>to_iterate;
	} while (to_iterate.length() == 1 &&(to_iterate.at(0) =='y' || to_iterate.at(0) =='Y' ));
	return 1;
} 

double getmoney(string money_str, char& money_key) 
{
	string nospace_data_string, whitespaces (" \t\f\v\n\r");
	size_t found;
	double money;
	if(white_space_remove(money_str,nospace_data_string ) < 0)
	{
		return -1.0;
	}
	if(nospace_data_string.at(0) =='$')
	{
		nospace_data_string =nospace_data_string .substr(1);
		money = stod(nospace_data_string); 
		money_key = DOLLAR_KEY;
	}
	else if ((found = nospace_data_string.find("Rs")) != string::npos)
	{
		nospace_data_string =nospace_data_string .substr(found + 2);
		money = stod(nospace_data_string); 
		money_key = RUPEE_KEY;
	}
	else
	{
	   cout<<"\n ERROR[04]: Invalid money data = "<<nospace_data_string;
	   money_key = OTHER_KEY;
	   return -1.0;	
	}
	cout<<"\n INFO[01]: Money = ";
	switch(money_key)
	{
		case DOLLAR_KEY:
			cout<<"$";
			break;
		case RUPEE_KEY:
		    cout<<"Rs";
			break;
		default:
		   cout<<"\n ERROR[05]: invalid money key "<<money_key;		
	}
	cout<<money<<endl;
	return money;
}

/* remove leading and trailng whitespace from input_string and store trunicated string in nospace_data_str
   eg if input_string = "  $24   ", then nospace_data_str = "$24" */
int white_space_remove(const string& input_string, string& nospace_data_str)
{
	size_t nonspace_lead , non_space_trail ;
	string whitespaces (" \t\f\v\n\r"), temp_str;	 
 	/* detect pos of char at leading white spaces*/  
	nonspace_lead = input_string.find_first_not_of(whitespaces);
	if(nonspace_lead == string::npos)
    {
	     if(DEBUG)
	        cout<<"\n ERROR[40]: ERROR_NO_LEAD_DATA, input_string = "<<input_string;
		  return ERROR_NO_LEAD_DATA;
	}

	/* detect pos of char at trailing white spaces*/
	non_space_trail = input_string.find_last_not_of(whitespaces);
    if (non_space_trail == string::npos)
    {
    	 if(DEBUG)
	        cout<<"\n ERROR[41]: ERROR_NO_TRAIL_DATA, input_string = "<<input_string;
	   return ERROR_NO_TRAIL_DATA; 
    }
  /* remove leading and trailng whitespace from input_string and store trunicated string in nospace_data_str */
	nospace_data_str = input_string.substr(nonspace_lead,non_space_trail -nonspace_lead + 1 );
	if(DEBUG)
	{
		cout<<"\n INFO[32]: extract data_string = "<<input_string<<", from "<<nonspace_lead<<" to "<<non_space_trail<<" , nospace_data_str = "<<nospace_data_str<<".";
	}
	    
	return non_space_trail;
}
