/* ********************************************************************
FILE                   : setw_mani.cpp

PROGRAM DESCRIPTION    : practise setw function to IO manipulate 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
long int pop1=2425785L, \
 pop2=47, pop3=9761;

cout<<setw(8)<<"LOCATION";
cout<<setw(12)<<"POPULATION" << endl;
cout<<setw(8)<<"Portcity" << setw(12) << pop1 << endl;
cout<<setiosflags (ios::left);
cout<<setw(8)<<"Hightown" << setw(12) << pop2 << endl;
cout<<setw(8)<<"Lowville" << setw(12) << pop3 << endl;
return 0;
}

