/* ********************************************************************
FILE                   : ex9-4.cpp

PROGRAM DESCRIPTION    : 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include <iostream>
#include <string>

using namespace std;
class publication
{
	string title;
	float price;
	public: 
	   void getdata()
	   {
	   	 cin.sync();
	   	 cout<<"\n Enter title = ";
	   	 getline(cin, title,'\n');
	   	 cout<<"\n Enter price = ";
	   	 cin>>price;
	   	 return;
	   }
	   void putdata()
	   {
	   	  cout<<"\n Title = "<<title;
	   	  cout<<"\n Price = "<<price;
	   	  return;
	   }
};

class sales
{
	enum {  NUM_MONTHS = 2	};
	float sales[NUM_MONTHS];
	public: 
	   void getdata()
	   {
	   	  for(int i =0 ; i<NUM_MONTHS;++i )
	   	  {
	   	     cout<<"\n Enter sales for month["<<i+1<<"] = ";
	   	     cin>>sales[i];
	      }
	   	  return;
	   }
	   void putdata()
	   {
	   	  for(int i =0 ; i<NUM_MONTHS;++i )
	   	  {
	   	     cout<<"\n Sales for month["<<i+1<<"] = "<<sales[i];	   	    
	      }
	   	  return;
	   }
};
/* book by a particular publication and particular publication's sales in last two months */
class book: private publication, private sales
{
	int pagecount;
	public:
		void getdata()
		{
			publication::getdata();
		    cout<<"\n Enter pagecount = ";
		    cin>>pagecount;
		    sales::getdata();
		    return;
     	}
     	void putdata()
		{
			publication::putdata();
		    cout<<"\n Pagecount = "<<pagecount;
		    sales::putdata();
		    return;
     	}
};
class tape: private publication, private sales
{
	float playtime;
	public:
		void getdata()
		{
			publication::getdata();
		    cout<<"\n Enter playtime = ";
		    cin>>playtime;
		    sales::getdata();
		    return;
     	}
     	void putdata()
		{
			publication::putdata();
		    cout<<"\n Playtime = "<<playtime;
		    sales::putdata();
		    return;
     	}
};
class disk:private publication, private sales
{
	private:
    enum disk_type{c,d};
	
    disk_type  disktype;
	public:
		void getdata()
		{
			string disk_str;
			cout<<"\n disk type: CD - c, DVD - d = ";
		    cin>>disk_str;
		    if(disk_str.compare("c") ==0)
		      disktype = c;
		    else if ( disk_str.compare("d") ==0 )
		      disktype = d;
		    else 
		    {
		      	cout<<"\n Invalid disk data = "<<disk_str;
		      	return;
		    }
		    publication::getdata();
		    sales::getdata();
		    return;
     	}
     	void putdata()
		{
			publication::putdata();
		    cout<<"\n Disk Type = "<< ((disktype)? "DVD" : "CD");
		    sales::putdata();
		    return;
     	}
};
 
int main() 
{
	book book_obj;
	disk disk_obj;
	
    book_obj.getdata();
	disk_obj.getdata();
	
	book_obj.putdata();
	disk_obj.putdata();
	
	return 1;
}
