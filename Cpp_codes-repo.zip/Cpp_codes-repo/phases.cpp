/* ********************************************************************
FILE                   : phases.cpp

PROGRAM DESCRIPTION    : 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <iostream>
using namespace std;
#include <conio.h> //for getche()
int main()
{
int chcount=0; //counts non-space characters
int wdcount=1; //counts spaces between words
char ch = 'a'; //ensure it isn�t �\r�
bool pre_word = true; // previous charater of a phase is ' '
cout << "Enter a phrase: ";
 while( ch != '\r' )
 //loop until Enter typed
{
ch = getche(); //read one character
if( ch==' ' && !pre_word )
{ //if it�s a word
wdcount++; //count a word
pre_word = true;
}
else if(ch!=' ')//iif a character is not a space,
{
chcount++; //count a character
pre_word = false;
}
} 

//display results
cout << "\nWords=" << wdcount << endl
<< "Letters=" << (chcount-1) << endl;

long dividend, divisor;
char to_iterate;

do {
cout << "\n Enter dividend: ";
cin >> dividend;
cout << "\n Enter divisor: ";
cin >> divisor;

if( divisor == 0 ) //if attempt to
{ //divide by 0,
cout << "\n Illegal divisor"; //display message
to_iterate = 'n'; /* exit loop after continue, checks do while condition, if loops next iteration */
continue; //go to top of loop

}
cout << "Quotient is " << dividend / divisor;
cout << ", remainder is " << dividend % divisor;
cout << "\nDo another? (y/n): ";
cin >> to_iterate;
} while( to_iterate != 'n' );
return 0;
}
