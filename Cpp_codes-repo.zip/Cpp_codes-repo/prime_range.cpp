/* ********************************************************************
FILE                   : prime_range.cpp

PROGRAM DESCRIPTION    : calc and display prime numbers in given range

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "iostream"
#include "string"
#include "cmath"
#include "stdlib.h"

#define MAX_NUM          1000
#define MAX_PRIME_COUNT   200
#define DEBUG 00
using namespace std;
class Prime
{
	private:
	    unsigned int arr_prime[MAX_PRIME_COUNT];
	    size_t prime_max_count;
	public: 
	    Prime();
	    unsigned int validate_input( string prime_input);
	    int calc_prime(unsigned  int max_prime); 
	    int disp_prime();
		    
};
Prime::Prime()
{
	prime_max_count = 0;
	arr_prime[prime_max_count] = 2;
}
unsigned int Prime::validate_input(string prime_input)
{
	string compare_string, str_prime;
	size_t sz, sz1, str_len;             
	long int int_prime_input ;
	str_len = prime_input.length();
	
	
	if( prime_input.at(0) == '+'  && str_len ==1 )
	{
		cout<<"\n ERROR[05]: Invalid prime input due to only '+': "<<prime_input;	
		cout<<"\n INFO[08]: Valid input number range[1,"<<MAX_NUM<<"]";	
		return 0;		
	}
	else if(prime_input.at(0) == '+' && !(prime_input.at(1) >= '0' && prime_input.at(1) <= '9' ) )
	{
		cout<<"\n ERROR[06]: Invalid prime input:["<<prime_input<<"] begins with + but next character is a not a integer";	
		cout<<"\n INFO[09]: Valid input number range[1,"<<MAX_NUM<<"]";	
		return 0;
	} 
	else if(prime_input.at(0) >= '0' && prime_input.at(0) <= '9' )
	{
		str_prime = prime_input;		
	} 
	else if(prime_input.at(0) == '+')
	{
		str_prime = prime_input.substr(1);
	}
    else
    {
        cout<<"\n ERROR[03]: Starting letter is not a number. \n Given number : "<<prime_input;
    	cout<<"\n INFO[10]: Valid input number range[1,"<<MAX_NUM<<"]";
    	return 0;
	}
    int_prime_input = stol (str_prime, &sz, 10);
	compare_string  = to_string(int_prime_input);
        /* compare with converted string wth given data to check given data is an integer */
    if(compare_string.compare(str_prime) == 0)
    {	
        if(int_prime_input<=0 || int_prime_input> MAX_NUM)
        {
           	cout<<"\n ERROR[02]: Number ["<<int_prime_input<<"] may be is <= 0 or > max limit ["<<MAX_NUM<<"]";   
			cout<<"\n INFO[11]: Valid input number range[1,"<<MAX_NUM<<"]";      
    	}
		return( (unsigned int )int_prime_input); 
	} 
	else 
	{
	      cout<<"\n ERROR[04]: Begins with number but has non integer characters.\n Given number : "<<prime_input;
		  cout<<"\n INFO[12]: Valid input number range[1,"<<MAX_NUM<<"]";		   
	}    
     
	return 0;
}
 int Prime::disp_prime( ) 
 {
 	size_t prime_count = 0;
    cout<<endl;
 	for(prime_count = 0; prime_count<prime_max_count; ++prime_count )
 	  cout<<" ["<<prime_count<<"]: "<<arr_prime[prime_count]<<",";
 	cout<<" ["<<prime_count<<"]: "<<arr_prime[prime_count]<<".";  
 	return 0;
 }
 int Prime::calc_prime(unsigned int max_prime) 
 {
 	unsigned int prime_count=0, num = 0, max_num_prime;
 	char is_prime='y';
 	if(max_prime <= 2 )
 	{
 	   switch(max_prime)
 	   {
 	   case 1:
 	   	 cout<<"\n 1 is a composite number ";
 	   	 return 0;
 	   case 2:
 	   	  cout<<"\n Display prime number ";
 	   	  disp_prime();  	   	  
 	   	  return 0;
 	   default:
 	   	  cout<<"\n ERROR[01]: Invalid number : "<<max_prime;
 	   	  return 1;
 	   }
    }
 	
 	for(num = 3; num <= max_prime; num = num + 2 )
 	{
      is_prime='y';	
      max_num_prime = (unsigned int) ceil(sqrt(double(num))) ;
      if(DEBUG)
          cout<<"\n INFO[02]: Number["<<num<<"] to find prime ["<<max_num_prime<<"]";
       for( prime_count = 0  ;  prime_count<=prime_max_count; ++prime_count )
 	  {
 	  	if(DEBUG)
 	       cout<<"\n INFO[03]: prime count ["<<prime_count<<"] number ["<<num<<"]";
 	  	 if( num % arr_prime[prime_count] == 0)
 	  	 {
 	  	 	if(DEBUG)
 	  	 	  cout<<"\n INFO[04]: Number["<<num<<"] is divisible by first prime["<< arr_prime[prime_count]<<"]";
 	  	 	is_prime='n';  
 	  	 	break;  
		 }		 	 		 
      }
      if(is_prime=='y')
	  {
	  	if(DEBUG)
		    cout<<"\n INFO[05]: Number["<<num<<"] is a prime number ";
		 ++prime_max_count;
		 arr_prime[prime_max_count] = num;		 	
	  }  
	} 	
	return 0; 
 }
int main()
{
	unsigned int prime_input;
	string to_continue, str_prime_input;
	Prime prime_obj;
	if(DEBUG)
	{
		cout<<"\n INFO[06]: Initial arr_prime";
	  prime_obj.disp_prime();  
    }  
	do
	{
	  cout<<"\n Enter max prime number : ";
	  cin>>str_prime_input;
	
	  prime_input = prime_obj.validate_input(str_prime_input);
	  if(prime_input)
	  {
	  
	      prime_obj.calc_prime(prime_input);
	      cout<<"\n Displaying prime numbers <= "<<prime_input;     
	      prime_obj.disp_prime();
      }
	  cout<<"\n Do you want to continue ? ";
	  cout<<"\n Press key 'y' or 'Y' to continue, any other key(s) to exit application. \n Enter - ";
	  cin>>to_continue;  
    } while(to_continue.length() == 1 && (to_continue.at(0) == 'y' || to_continue.at(0) == 'Y') );
    return 0;	
}
