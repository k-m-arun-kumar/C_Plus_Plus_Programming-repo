/* ********************************************************************
FILE                   : rev_str.cpp

PROGRAM DESCRIPTION    : reverse a given string

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <iostream>
#include <cstring>
using namespace std;
#define MAX  30

void reverse_str(char[], char[]);
int main()
{
	char str[MAX], rev_str[MAX];
	cout<<"\n Enter a string : ";
	cin.get(str, MAX);
	reverse_str(str,rev_str );

	return 1;
}
void reverse_str(char str[], char rev_str[] )
{
	int i = 0, j;
   for( i = 0,  j =strlen(str) -1 ; i< strlen(str); ++i, --j)
	{
		rev_str[i] = str[j];
	}
	rev_str[i] = '\0';
	cout<<"\n str = "<<str<<", rev_str = "<<rev_str;
	return; 
}
